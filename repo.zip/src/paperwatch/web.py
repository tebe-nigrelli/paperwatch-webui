from __future__ import annotations

import csv
import hashlib
import html
import inspect
import io
import os
import sqlite3
import tempfile
import zipfile
import json
import re
import shutil
import subprocess
import threading
import uuid
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import quote_plus, urlencode, urlparse

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.background import BackgroundTask
from starlette.datastructures import UploadFile

from . import __version__
from .analysis_jobs import AnalysisController
from .blog_import import import_blog_links
from .blogs import (
    SOURCE_MODES,
    blog_diff,
    normalize_blog_url,
    normalize_source_mode,
    validate_article_url_pattern,
    validate_content_selector,
)
from .config import AppConfig, load_config
from .db import Database
from .job_runtime import ProgressCallback
from .locking import AnalysisAlreadyInProgress, analysis_lock
from .models import (
    AuthorCandidate,
    PaperAuthor,
    PaperRecord,
    clean_text,
    extract_arxiv_id,
    short_openalex_id,
    strip_doi,
)
from .pdfs import PDFError, download_pdf, pdf_sha256, safe_pdf_name, validate_pdf_file
from .query_jobs import QueryController
from .sources.openalex import OpenAlexClient

PAPER_KINDS = (
    "mathematics",
    "machine_learning",
    "theoretical_machine_learning",
    "survey",
    "other",
)
SCOPES = ("abstract", "fulltext")
SORTS = ("newest", "oldest", "discovered", "title")
PAGE_SIZES = (25, 100, 250, 500, 1000)
DEFAULT_PAGE_SIZE = 100
DEFAULT_CONTEXT_WINDOW_TOKENS = 16384


@dataclass(frozen=True, slots=True)
class PaperFilters:
    query: str = ""
    title_query: str = ""
    author_id: str = ""
    author_ids: tuple[str, ...] = ()
    author_tags: tuple[str, ...] = ()
    content_tags: tuple[str, ...] = ()
    topic_id: str = ""
    topic_ids: tuple[str, ...] = ()
    paper_kind: str = ""
    scope: str = ""
    has_pdf: bool | None = None
    analyzed: bool | None = None
    starred: bool | None = None
    read: bool | None = None
    date_from: str = ""
    date_to: str = ""
    sort: str = "newest"
    page: int = 1
    page_size: int = DEFAULT_PAGE_SIZE

    def selection(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "title_query": self.title_query,
            "author_id": self.author_id,
            "author_ids": list(self.author_ids),
            "author_tags": list(self.author_tags),
            "content_tags": list(self.content_tags),
            "topic_id": self.topic_id,
            "topic_ids": list(self.topic_ids),
            "paper_kind": self.paper_kind,
            "scope": self.scope,
            "has_pdf": self.has_pdf,
            "analyzed": self.analyzed,
            "starred": self.starred,
            "read": self.read,
            "date_from": self.date_from,
            "date_to": self.date_to,
            "sort": self.sort,
        }

    def selection_items(self) -> list[tuple[str, str]]:
        items = [
            ("q", self.query),
            ("title", self.title_query),
            *(("author", value) for value in (self.author_ids or ((self.author_id,) if self.author_id else ()))),
            *(("author_tag", tag) for tag in self.author_tags),
            *(("tag", tag) for tag in self.content_tags),
            *(("topic", value) for value in (self.topic_ids or ((self.topic_id,) if self.topic_id else ()))),
            ("kind", self.paper_kind),
            ("scope", self.scope),
            ("has_pdf", _bool_query(self.has_pdf)),
            ("analyzed", _bool_query(self.analyzed)),
            ("starred", _bool_query(self.starred)),
            ("read", _bool_query(self.read)),
            ("date_from", self.date_from),
            ("date_to", self.date_to),
            ("sort", self.sort if self.sort != "newest" else ""),
        ]
        return [(key, value) for key, value in items if value]

    def query_items(self, *, page: int | None = None) -> list[tuple[str, str]]:
        items = [
            ("q", self.query),
            ("title", self.title_query),
            *(("author", value) for value in (self.author_ids or ((self.author_id,) if self.author_id else ()))),
            *(("author_tag", tag) for tag in self.author_tags),
            *(("tag", tag) for tag in self.content_tags),
            *(("topic", value) for value in (self.topic_ids or ((self.topic_id,) if self.topic_id else ()))),
            ("kind", self.paper_kind),
            ("scope", self.scope),
            ("has_pdf", _bool_query(self.has_pdf)),
            ("analyzed", _bool_query(self.analyzed)),
            ("starred", _bool_query(self.starred)),
            ("read", _bool_query(self.read)),
            ("date_from", self.date_from),
            ("date_to", self.date_to),
            ("sort", self.sort if self.sort != "newest" else ""),
            ("page_size", str(self.page_size) if self.page_size != DEFAULT_PAGE_SIZE else ""),
            ("page", str(page if page is not None else self.page)),
        ]
        return [(key, value) for key, value in items if value and value != "1"]

    @property
    def query_string(self) -> str:
        return urlencode(self.query_items())


@dataclass(slots=True)
class RunSnapshot:
    running: bool = False
    mode: str | None = None
    query: str | None = None
    paper_id: int | None = None
    started_at: str | None = None
    finished_at: str | None = None
    run_id: int | None = None
    status: str | None = None
    stats: dict[str, Any] | None = None
    error: str | None = None
    cancelled: bool = False
    cancel_requested: bool = False
    progress_current: int = 0
    progress_total: int = 0
    stage: str = ""
    message: str = ""


class RunController:
    """Allow one in-process fetch at a time without sharing SQLite connections."""

    def __init__(
        self,
        config_path: str | Path,
        runner: Callable[[Path, str], dict[str, Any]] | None = None,
    ) -> None:
        self.config_path = Path(config_path).resolve()
        self._runner = runner or _run_pipeline
        self._lock = threading.Lock()
        self._snapshot = RunSnapshot()
        self._thread: threading.Thread | None = None
        self._cancel_event = threading.Event()

    def start(self, mode: str = "run", query: str | None = None) -> bool:
        if mode not in {"run", "backfill", "search", "download"}:
            raise ValueError("Unknown run mode")
        normalized_query = query.strip() if query else None
        if mode in {"search", "download"} and not normalized_query:
            raise ValueError("Paper identifier cannot be empty")
        with self._lock:
            if self._snapshot.running:
                return False
            self._cancel_event = threading.Event()
            self._snapshot = RunSnapshot(
                running=True,
                mode=mode,
                query=normalized_query,
                started_at=_utcnow(),
                status="running",
                stage="Queued",
                message="Preparing fetch",
            )
            self._thread = threading.Thread(
                target=self._work,
                args=(mode, normalized_query),
                name="paperwatch-web-run",
                daemon=True,
            )
            self._thread.start()
            return True

    def _work(self, mode: str, query: str | None) -> None:
        try:
            parameter_count = len(inspect.signature(self._runner).parameters)
            if parameter_count >= 5:
                result = self._runner(
                    self.config_path,
                    mode,
                    query,
                    self._progress,
                    self._cancel_event,
                )
            elif parameter_count >= 3:
                result = self._runner(self.config_path, mode, query)
            else:
                result = self._runner(self.config_path, mode)
            with self._lock:
                self._snapshot.running = False
                self._snapshot.finished_at = _utcnow()
                self._snapshot.run_id = _int_or_none(result.get("run_id"))
                self._snapshot.paper_id = _int_or_none(result.get("paper_id"))
                self._snapshot.status = str(result.get("status") or "success")
                self._snapshot.stats = dict(result)
                self._snapshot.cancelled = self._snapshot.status == "cancelled"
                self._snapshot.cancel_requested = False
                self._snapshot.stage = (
                    "Cancelled" if self._snapshot.cancelled else "Complete"
                )
        except Exception as exc:
            with self._lock:
                self._snapshot.running = False
                self._snapshot.finished_at = _utcnow()
                self._snapshot.status = "failed"
                self._snapshot.error = str(exc)
                self._snapshot.cancel_requested = False
                self._snapshot.stage = "Failed"
                self._snapshot.message = str(exc)

    def _progress(self, kind: str, value: str) -> None:
        with self._lock:
            if kind == "stage":
                self._snapshot.stage = value[:200]
            elif kind == "message":
                self._snapshot.message = value[:1000]
            elif kind == "progress":
                current, separator, total = value.partition("/")
                if separator:
                    self._snapshot.progress_current = _int_or_none(current) or 0
                    self._snapshot.progress_total = _int_or_none(total) or 0

    def cancel(self) -> bool:
        with self._lock:
            if not self._snapshot.running:
                return False
            self._snapshot.cancel_requested = True
            self._snapshot.message = "Stopping after the current network operation"
            self._cancel_event.set()
        return True

    def snapshot(self) -> RunSnapshot:
        with self._lock:
            return RunSnapshot(**asdict(self._snapshot))

    def wait(self, timeout: float = 10) -> None:
        thread = self._thread
        if thread:
            thread.join(timeout)


def _run_pipeline(
    config_path: Path,
    mode: str = "run",
    query: str | None = None,
    progress: ProgressCallback | None = None,
    cancel_event: threading.Event | None = None,
) -> dict[str, Any]:
    from .cli import build_services
    from .pipeline import PaperWatch

    config = load_config(config_path)
    services = build_services(config)
    app: PaperWatch | None = None
    try:
        app = PaperWatch(
            config,
            db=services.db,
            openalex=services.openalex,
            arxiv=services.arxiv,
            llm=services.llm,
            progress=progress,
            cancel_event=cancel_event,
        )
        paper_id: int | None = None
        if mode == "backfill":
            current_day = datetime.now(timezone.utc).date()
            stats = app.run(
                today=current_day,
                since_override=current_day - timedelta(days=365),
                download_only=True,
                historical=True,
                max_papers_per_author_override=5000,
            )
        elif mode == "search":
            stats, paper_id = app.fetch_title(query or "")
        elif mode == "download":
            stats, paper_id = app.fetch_work(query or "")
        elif mode == "run":
            stats = app.run()
        else:
            raise ValueError("Unknown run mode")
        return {
            "run_id": stats.run_id,
            "status": stats.status,
            "paper_id": paper_id,
            **stats.as_dict(),
        }
    finally:
        if app is not None:
            app.close()
        services.close()


def _utcnow() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _bool_query(value: bool | None) -> str:
    if value is True:
        return "yes"
    if value is False:
        return "no"
    return ""


def _parse_tristate(value: str | None) -> bool | None:
    if value in {"yes", "true", "1"}:
        return True
    if value in {"no", "false", "0"}:
        return False
    return None


def _valid_date(value: str | None) -> str:
    if not value:
        return ""
    try:
        return date.fromisoformat(value).isoformat()
    except ValueError:
        return ""


def _manual_author_names(value: str) -> list[str]:
    separator = r"[\n;]+" if re.search(r"[\n;]", value) else r","
    names = [clean_text(item) for item in re.split(separator, value)]
    unique: list[str] = []
    seen: set[str] = set()
    for name in names:
        if not name:
            continue
        key = name.casefold()
        if key not in seen:
            seen.add(key)
            unique.append(name)
    if not unique:
        raise ValueError("At least one author is required")
    if len(unique) > 200:
        raise ValueError("At most 200 authors can be imported")
    return unique


def _manual_source_url(value: str) -> str:
    source = clean_text(value)
    if not source:
        raise ValueError("Source link is required")
    if len(source) > 2000:
        raise ValueError("Source link is too long")
    parsed = urlparse(source)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Source link must be a valid http or https URL")
    return source


def _manual_openalex_author_id(value: str) -> str | None:
    cleaned = short_openalex_id(clean_text(value))
    if not cleaned:
        return None
    if not re.fullmatch(r"A\d+", cleaned):
        raise ValueError("OpenAlex author ID must look like A123456789")
    return cleaned


def _manual_publication_date(value: str) -> str | None:
    cleaned = value.strip()
    if not cleaned:
        return None
    try:
        return date.fromisoformat(cleaned).isoformat()
    except ValueError as exc:
        raise ValueError("Publication date must use YYYY-MM-DD") from exc


def _manual_paper_record(values: dict[str, str], *, filename: str) -> PaperRecord:
    title = clean_text(values.get("title"))
    if not title:
        raise ValueError("Title is required")
    if len(title) > 1000:
        raise ValueError("Title is too long")
    authors = _manual_author_names(values.get("authors", ""))
    source_url = _manual_source_url(values.get("source_link", ""))
    abstract = clean_text(values.get("abstract"))
    if abstract and len(abstract) > 1_000_000:
        raise ValueError("Abstract is too long")
    venue = clean_text(values.get("venue"))
    if venue and len(venue) > 500:
        raise ValueError("Venue is too long")
    doi = strip_doi(values.get("doi"))
    arxiv_raw = clean_text(values.get("arxiv_id"))
    arxiv_id = extract_arxiv_id(f"arxiv:{arxiv_raw}") if arxiv_raw else None
    if arxiv_raw and not arxiv_id:
        raise ValueError("arXiv ID is invalid")
    publication_date = _manual_publication_date(values.get("publication_date", ""))
    paper_authors = [
        PaperAuthor(
            openalex_id=None,
            name=name,
            position=(
                "first"
                if index == 0
                else "last"
                if index == len(authors) - 1
                else "middle"
            ),
        )
        for index, name in enumerate(authors)
    ]
    return PaperRecord(
        openalex_id=None,
        doi=doi,
        arxiv_id=arxiv_id,
        title=title,
        abstract=abstract,
        publication_date=publication_date,
        updated_date=None,
        venue=venue,
        publication_url=source_url,
        pdf_url=None,
        abstract_source="manual" if abstract else None,
        pdf_source="manual_upload",
        authors=paper_authors,
        metadata={
            "manual_import": True,
            "original_filename": Path(filename).name,
            "source_link": source_url,
            "imported_at": _utcnow(),
        },
    )


async def _stage_uploaded_pdf(
    upload: UploadFile,
    *,
    directory: Path,
    max_bytes: int,
) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    temporary = directory / f".manual-upload-{uuid.uuid4().hex}.pdf.part"
    total = 0
    try:
        with temporary.open("xb") as handle:
            while True:
                chunk = await upload.read(64 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise PDFError(f"PDF exceeds maximum size of {max_bytes} bytes")
                handle.write(chunk)
        if total == 0:
            raise PDFError("PDF file is empty")
        validate_pdf_file(temporary)
        return temporary
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()


def _parse_filter_values(params: Any) -> PaperFilters:
    page = max(1, _int_or_none(params.get("page")) or 1)
    page_size = _int_or_none(params.get("page_size")) or DEFAULT_PAGE_SIZE
    if page_size not in PAGE_SIZES:
        page_size = DEFAULT_PAGE_SIZE
    paper_kind = params.get("kind", "")
    if paper_kind not in PAPER_KINDS:
        paper_kind = ""
    scope = params.get("scope", "")
    if scope not in SCOPES:
        scope = ""
    sort = params.get("sort", "newest")
    if sort not in SORTS:
        sort = "newest"
    raw_topics = params.getlist("topic") if hasattr(params, "getlist") else params.get("topic", ())
    if isinstance(raw_topics, str):
        raw_topics = (raw_topics,)
    topic_ids = tuple(dict.fromkeys(
        candidate for value in (raw_topics or ())
        if (candidate := short_openalex_id(str(value).strip()[:64]) or "").startswith("T")
    ))[:50]
    topic_id = topic_ids[0] if topic_ids else ""
    raw_authors = params.getlist("author") if hasattr(params, "getlist") else params.get("author", ())
    if isinstance(raw_authors, str):
        raw_authors = (raw_authors,)
    author_ids = tuple(dict.fromkeys(
        candidate for value in (raw_authors or ())
        if (candidate := short_openalex_id(str(value).strip()[:64]) or str(value).strip()[:64])
    ))[:50]
    author_id = author_ids[0] if author_ids else ""
    raw_author_tags = (
        params.getlist("author_tag")
        if hasattr(params, "getlist")
        else params.get("author_tag", ())
    )
    if isinstance(raw_author_tags, str):
        raw_author_tags = (raw_author_tags,)
    author_tags: list[str] = []
    seen_tags: set[str] = set()
    for value in raw_author_tags or ():
        tag = " ".join(str(value).strip().split())[:40]
        normalized = tag.casefold()
        if tag and normalized not in seen_tags:
            author_tags.append(tag)
            seen_tags.add(normalized)
        if len(author_tags) >= 50:
            break
    raw_content_tags = (
        params.getlist("tag")
        if hasattr(params, "getlist")
        else params.get("tag", ())
    )
    if isinstance(raw_content_tags, str):
        raw_content_tags = (raw_content_tags,)
    content_tags: list[str] = []
    seen_content_tags: set[str] = set()
    for value in raw_content_tags or ():
        tag = " ".join(str(value).strip().split())[:80]
        normalized = tag.casefold()
        if tag and normalized not in seen_content_tags:
            content_tags.append(tag)
            seen_content_tags.add(normalized)
        if len(content_tags) >= 50:
            break
    return PaperFilters(
        query=params.get("q", "").strip()[:200],
        title_query=params.get("title", "").strip()[:300],
        author_id=author_id,
        author_ids=author_ids,
        author_tags=tuple(author_tags),
        content_tags=tuple(content_tags),
        topic_id=topic_id,
        topic_ids=topic_ids,
        paper_kind=paper_kind,
        scope=scope,
        has_pdf=_parse_tristate(params.get("has_pdf")),
        analyzed=_parse_tristate(params.get("analyzed")),
        starred=_parse_tristate(params.get("starred")),
        read=_parse_tristate(params.get("read")),
        date_from=_valid_date(params.get("date_from")),
        date_to=_valid_date(params.get("date_to")),
        sort=sort,
        page=page,
        page_size=page_size,
    )


def _parse_filters(request: Request) -> PaperFilters:
    return _parse_filter_values(request.query_params)


def _content_tag_values(params: Any) -> tuple[str, ...]:
    raw = params.getlist("tag") if hasattr(params, "getlist") else params.get("tag", ())
    if isinstance(raw, str):
        raw = (raw,)
    values: list[str] = []
    seen: set[str] = set()
    for value in raw or ():
        cleaned = " ".join(str(value).strip().split())[:80]
        key = cleaned.casefold()
        if cleaned and key not in seen:
            values.append(cleaned)
            seen.add(key)
    return tuple(values[:50])


def _split_tags(value: str) -> tuple[str, ...]:
    values: list[str] = []
    seen: set[str] = set()
    for raw in re.split(r"[,;\n]", value):
        cleaned = " ".join(raw.strip().split())[:80]
        key = cleaned.casefold()
        if cleaned and key not in seen:
            values.append(cleaned)
            seen.add(key)
        if len(values) >= 100:
            break
    return tuple(values)


def _request_return_path(request: Request, fallback: str = "/") -> str:
    referer = urlparse(request.headers.get("referer", ""))
    if referer.path.startswith("/") and not referer.path.startswith("//"):
        return f"{referer.path}?{referer.query}" if referer.query else referer.path
    return fallback


def _async_request(request: Request) -> bool:
    return request.headers.get("X-Paperwatch-Async") == "1"


def _json_value(value: Any, fallback: Any) -> Any:
    if value in (None, ""):
        return fallback
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return fallback


def _row_dict(row: Any) -> dict[str, Any]:
    return dict(row) if row is not None else {}


def _query_profile_names(value: Any) -> tuple[str, ...]:
    decoded = _json_value(value, [])
    if not isinstance(decoded, list):
        return ()
    return tuple(dict.fromkeys(
        str(item).strip() for item in decoded if str(item).strip()
    ))


def _query_view(row: Any, config: AppConfig) -> dict[str, Any]:
    query = _row_dict(row)
    available = {item.profile: item for item in config.available_llms}
    selected = _query_profile_names(query.get("model_profiles_json"))
    if not selected and available:
        selected = (next(iter(available)),)
    query["model_profiles"] = list(selected)
    query["selected_models"] = [
        {
            "profile": name,
            "model": available[name].model if name in available else "Unavailable",
            "provider": available[name].provider if name in available else "missing",
        }
        for name in selected
    ]
    query["context_window_tokens"] = int(
        query.get("context_window_tokens") or DEFAULT_CONTEXT_WINDOW_TOKENS
    )
    query["paper_source_scope"] = str(query.get("paper_source_scope") or "auto")
    query["pdf_strategy"] = str(query.get("pdf_strategy") or "chunked")
    query["regexp_pattern"] = str(query.get("regexp_pattern") or "")
    query["regexp_radius"] = int(query.get("regexp_radius") or 0)
    query["regexp_mode"] = str(query.get("regexp_mode") or "query")
    query["content_scope"] = str(query.get("content_scope") or "both")
    query["query_kind"] = str(query.get("query_kind") or "summary")
    query["label_class"] = str(query.get("label_class") or "")
    label_values = _json_value(query.get("label_values_json"), [])
    if not isinstance(label_values, list):
        label_values = []
    query["label_values"] = [
        {
            "value": str(item.get("value") or ""),
            "pattern": str(item.get("pattern") or ""),
        }
        for item in label_values
        if isinstance(item, dict) and item.get("value") and item.get("pattern")
    ]
    query["label_values_text"] = "\n".join(
        f"{item['value']} = {item['pattern']}" for item in query["label_values"]
    )
    query["local_regexp"] = bool(
        query["regexp_pattern"] and query["regexp_mode"] == "print"
    )
    return query


def _classification_form_values(value: str) -> list[dict[str, str]]:
    values: list[dict[str, str]] = []
    for raw_line in value.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ValueError("Each classification value must use: Label = regexp")
        label, pattern = line.split("=", 1)
        values.append({"value": label.strip(), "pattern": pattern.strip()})
    return values


def _query_execution_form(form: Any, config: AppConfig) -> dict[str, Any]:
    available = {item.profile: item for item in config.available_llms}
    profiles = tuple(dict.fromkeys(
        str(value).strip() for value in form.getlist("model") if str(value).strip()
    ))
    unknown = [name for name in profiles if name not in available]
    if unknown:
        raise ValueError(f"Unknown configured model profile(s): {', '.join(unknown)}")
    if available and not profiles:
        profiles = (next(iter(available)),)
    context = _int_or_none(form.get("context_window_tokens"))
    if context is None:
        context = config.llm.context_window_tokens
    source_scope = str(form.get("paper_source_scope", "auto"))
    pdf_strategy = str(form.get("pdf_strategy", "chunked"))
    if source_scope == "abstract":
        pdf_strategy = "auto"
    regexp_radius = _int_or_none(form.get("regexp_radius"))
    if regexp_radius is None:
        regexp_radius = 0
    query_kind = str(form.get("query_kind", "summary"))
    return {
        "model_profiles": profiles,
        "context_window_tokens": context,
        "paper_source_scope": source_scope,
        "pdf_strategy": pdf_strategy,
        "regexp_pattern": str(form.get("regexp_pattern", "")),
        "regexp_radius": regexp_radius,
        "regexp_mode": str(form.get("regexp_mode", "query")),
        "content_scope": str(form.get("content_scope", "both")),
        "query_kind": query_kind,
        "label_class": str(form.get("label_class", "")),
        "label_values": (
            _classification_form_values(str(form.get("label_values", "")))
            if query_kind == "classification"
            else []
        ),
    }


def _query_supports(query: Any, content_type: str) -> bool:
    scope = str(query.get("content_scope", "both") if isinstance(query, dict) else query["content_scope"] or "both")
    return scope == "both" or scope == content_type


def _analysis_view(row: Any) -> dict[str, Any]:
    data = _row_dict(row)
    result = _json_value(data.get("result_json"), {})
    data["result"] = result
    data["usage"] = _json_value(data.get("usage_json"), {})
    return data


def _paper_export(db: Database, row: Any) -> dict[str, Any]:
    paper = _row_dict(row)
    paper["metadata"] = _json_value(paper.pop("metadata_json", "{}"), {})
    exported_authors = []
    for item in db.paper_authors(int(paper["id"])):
        author = _row_dict(item)
        author.pop("tracked_enabled", None)
        author.pop("is_tracked", None)
        exported_authors.append(author)
    paper["authors"] = exported_authors
    paper["topics"] = [
        {
            "openalex_id": item["openalex_id"],
            "display_name": item["display_name"],
            "score": item["score"],
            "is_primary": bool(item["is_primary"]),
            "subfield": {
                "id": item["subfield_id"],
                "display_name": item["subfield_name"],
            },
            "field": {
                "id": item["field_id"],
                "display_name": item["field_name"],
            },
            "domain": {
                "id": item["domain_id"],
                "display_name": item["domain_name"],
            },
        }
        for item in db.paper_topics(int(paper["id"]))
    ]
    paper["analyses"] = [
        _json_value(item["result_json"], {}) | {
            "analysis_id": item["id"],
            "scope": item["scope"],
            "provider": item["provider"],
            "model": item["model"],
            "prompt_version": item["prompt_version"],
            "created_at": item["created_at"],
            "usage": _json_value(item["usage_json"], {}),
        }
        for item in db.paper_analyses(int(paper["id"]))
    ]
    for key in (
        "author_names", "topics_json", "analysis_count", "latest_scope",
        "latest_kind", "latest_summary"
    ):
        paper.pop(key, None)
    return paper


def _all_filtered(db: Database, filters: PaperFilters) -> list[Any]:
    rows, _ = db.search_papers(
        query=filters.query,
        title_query=filters.title_query,
        author_id=filters.author_id,
        author_ids=filters.author_ids,
        author_tags=filters.author_tags,
        content_tags=filters.content_tags,
        topic_id=filters.topic_id,
        topic_ids=filters.topic_ids,
        paper_kind=filters.paper_kind,
        scope=filters.scope,
        has_pdf=filters.has_pdf,
        analyzed=filters.analyzed,
        date_from=filters.date_from,
        date_to=filters.date_to,
        sort=filters.sort,
        limit=None,
        offset=0,
    )
    return rows


def _content_kind(value: str | None, default: str = "all") -> str:
    normalized = str(value or default).strip().lower()
    return normalized if normalized in {"all", "papers", "blogs"} else default


def _website_view(value: str) -> tuple[str, str]:
    parsed = urlparse(str(value or ""))
    host = (parsed.hostname or "").lower()
    display = host.removeprefix("www.") or str(value or "")
    if parsed.scheme.lower() in {"http", "https"} and parsed.netloc:
        return display, f"{parsed.scheme.lower()}://{parsed.netloc}/"
    return display, str(value or "")


def _record_sort_key(record: dict[str, Any], sort: str) -> tuple[Any, ...]:
    if sort == "title":
        return (str(record.get("title") or "").casefold(), int(record.get("id") or 0))
    date_value = str(record.get("record_date") or "")
    if sort == "oldest":
        return (date_value or "9999-12-31", int(record.get("id") or 0))
    if sort == "discovered":
        return (str(record.get("record_fetched") or ""), int(record.get("id") or 0))
    return (date_value, int(record.get("id") or 0))


def _safe_markdown_url(value: str) -> str | None:
    parsed = urlparse(html.unescape(value).strip())
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        return None
    return parsed.geturl()


def _render_stored_markdown(value: str) -> str:
    """Render stored summaries and extracted blog markdown without raw HTML.

    Remote images remain URLs. Browsers fetch them only while the detail page is open;
    Paperwatch never stores the image bytes.
    """
    image_pattern = re.compile(r"!\[([^\]]*)\]\((https?://[^\s\)]+)\)")
    link_pattern = re.compile(r"(?<!!)\[([^\]]+)\]\((https?://[^\s\)]+)\)")

    def image(match: re.Match[str]) -> str:
        url = _safe_markdown_url(match.group(2))
        if url is None:
            return match.group(0)
        alt = html.escape(html.unescape(match.group(1)) or "Image")
        safe_url = html.escape(url, quote=True)
        return (
            '<figure class="remote-blog-image"><a href="' + safe_url + '" '
            'target="_blank" rel="noreferrer noopener"><img src="' + safe_url + '" '
            'alt="' + alt + '" loading="lazy" decoding="async" '
            'referrerpolicy="no-referrer"></a><figcaption><a href="' + safe_url + '" '
            'target="_blank" rel="noreferrer noopener">Open image</a></figcaption></figure>'
        )

    def link(match: re.Match[str]) -> str:
        url = _safe_markdown_url(match.group(2))
        if url is None:
            return match.group(0)
        label = html.escape(html.unescape(match.group(1)))
        return (
            '<a href="' + html.escape(url, quote=True) + '" target="_blank" '
            'rel="noreferrer noopener">' + label + '</a>'
        )

    def inline(raw: str) -> str:
        escaped = html.escape(raw)
        code_values: list[str] = []

        def code(match: re.Match[str]) -> str:
            code_values.append(f"<code>{match.group(1)}</code>")
            return f"\x00CODE{len(code_values) - 1}\x00"

        escaped = re.sub(r"`([^`\n]+)`", code, escaped)
        escaped = image_pattern.sub(image, escaped)
        escaped = link_pattern.sub(link, escaped)
        escaped = re.sub(
            r"!?\[([^\]]*)\]\((?!https?://)[^\)]*\)",
            lambda match: html.escape(html.unescape(match.group(1))),
            escaped,
            flags=re.IGNORECASE,
        )
        escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
        escaped = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<em>\1</em>", escaped)
        for index, rendered in enumerate(code_values):
            escaped = escaped.replace(f"\x00CODE{index}\x00", rendered)
        return escaped

    lines = (value or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks: list[str] = []
    paragraph: list[str] = []
    list_items: list[str] = []
    list_kind = "ul"
    quote_lines: list[str] = []
    code_lines: list[str] = []
    in_code = False

    def flush_paragraph() -> None:
        if paragraph:
            rendered = "<br>".join(inline(line) for line in paragraph)
            if rendered.startswith("<figure") and rendered.endswith("</figure>"):
                blocks.append(rendered)
            else:
                blocks.append(f"<p>{rendered}</p>")
            paragraph.clear()

    def flush_list() -> None:
        if list_items:
            blocks.append(
                f"<{list_kind}>" + "".join(f"<li>{inline(item)}</li>" for item in list_items) + f"</{list_kind}>"
            )
            list_items.clear()

    def flush_quote() -> None:
        if quote_lines:
            blocks.append(f"<blockquote>{'<br>'.join(inline(line) for line in quote_lines)}</blockquote>")
            quote_lines.clear()

    for line in lines:
        if line.strip().startswith("```"):
            flush_paragraph()
            flush_list()
            flush_quote()
            if in_code:
                blocks.append(f"<pre><code>{html.escape(chr(10).join(code_lines))}</code></pre>")
                code_lines.clear()
            in_code = not in_code
            continue
        if in_code:
            code_lines.append(line)
            continue
        if not line.strip():
            flush_paragraph()
            flush_list()
            flush_quote()
            continue
        heading = re.match(r"^(#{1,6})\s+(.+)$", line)
        if heading:
            flush_paragraph()
            flush_list()
            flush_quote()
            level = len(heading.group(1))
            blocks.append(f"<h{level}>{inline(heading.group(2))}</h{level}>")
            continue
        unordered = re.match(r"^\s*[-*+]\s+(.+)$", line)
        ordered = re.match(r"^\s*\d+[.)]\s+(.+)$", line)
        if unordered or ordered:
            flush_paragraph()
            flush_quote()
            kind = "ol" if ordered else "ul"
            if list_items and kind != list_kind:
                flush_list()
            list_kind = kind
            list_items.append((ordered or unordered).group(1))
            continue
        if line.lstrip().startswith(">"):
            flush_paragraph()
            flush_list()
            quote_lines.append(line.lstrip()[1:].lstrip())
            continue
        flush_list()
        flush_quote()
        paragraph.append(line)
    if in_code and code_lines:
        blocks.append(f"<pre><code>{html.escape(chr(10).join(code_lines))}</code></pre>")
    flush_paragraph()
    flush_list()
    flush_quote()
    return "".join(blocks)


def _notice_url(path: str, message: str, *, level: str = "success") -> str:
    separator = "&" if "?" in path else "?"
    return f"{path}{separator}{urlencode({'notice': message, 'level': level})}"


def _author_client(config: AppConfig) -> OpenAlexClient:
    return OpenAlexClient(
        api_key=config.openalex.api_key,
        base_url=config.openalex.base_url,
        timeout_seconds=config.openalex.timeout_seconds,
    )


def _author_view(row: Any) -> dict[str, Any]:
    data = _row_dict(row)
    name = str(data.get("name") or "Unknown author")
    author_id = str(data.get("openalex_author_id") or data.get("openalex_id") or "")
    scholar_query = quote_plus(f'author:"{name}"')
    encoded_name = quote_plus(name)
    data.update(
        {
            "author_id": author_id,
            "papers_url": (
                f"/?author={quote_plus(author_id)}"
                if author_id
                else f"/?q={encoded_name}"
            ),
            "author_url": f"/authors/{quote_plus(author_id)}/blogs" if author_id else "/authors",
            "google_scholar_url": f"https://scholar.google.com/scholar?q={scholar_query}",
            "openalex_url": (f"https://openalex.org/authors/{author_id.lower()}" if author_id else None),
            "arxiv_url": f"https://arxiv.org/search/?query={encoded_name}&searchtype=author",
        }
    )
    return data


def _paper_view(row: Any) -> dict[str, Any]:
    data = _row_dict(row)
    topics = _json_value(data.get("topics_json"), [])
    data["topics"] = topics if isinstance(topics, list) else []
    title = str(data.get("title") or "")
    data["google_scholar_url"] = (
        f"https://scholar.google.com/scholar?q={quote_plus('\"' + title + '\"')}"
        if title else None
    )
    openalex_id = str(data.get("openalex_id") or "")
    data["openalex_url"] = (
        f"https://openalex.org/works/{openalex_id.lower()}" if openalex_id else None
    )
    arxiv_id = str(data.get("arxiv_id") or "")
    data["arxiv_url"] = f"https://arxiv.org/abs/{quote_plus(arxiv_id)}" if arxiv_id else None
    return data


def _paper_pdf_state(db: Database, data: dict[str, Any]) -> dict[str, Any]:
    value = str(data.get("local_pdf_path") or "").strip()
    data["pdf_modified"] = False
    data["pdf_missing_on_disk"] = False
    if not value:
        return data
    path = Path(value).expanduser()
    if not path.is_file():
        data["pdf_modified"] = True
        data["pdf_missing_on_disk"] = True
        return data
    try:
        current = pdf_sha256(path)
    except PDFError:
        data["pdf_modified"] = True
        return data
    stored = str(data.get("pdf_sha256") or "")
    if not stored:
        db.set_paper_pdf_hash(int(data["id"]), current)
        data["pdf_sha256"] = current
    else:
        data["pdf_modified"] = stored != current
    data["current_pdf_sha256"] = current
    return data


def _paper_table_view(db: Database, row: Any) -> dict[str, Any]:
    data = _paper_pdf_state(db, _paper_view(row))
    paper_authors = [_author_view(item) for item in db.paper_authors(int(data["id"]))]
    tracked_authors = [item for item in paper_authors if bool(item.get("is_tracked"))]
    data["tracked_authors"] = tracked_authors
    data["other_author_count"] = max(0, len(paper_authors) - len(tracked_authors))
    data["all_authors"] = paper_authors
    return data


def _selection_with_labels(
    filters: PaperFilters,
    *,
    authors: Iterable[Any],
    topics: Iterable[Any],
) -> dict[str, Any]:
    selection = filters.selection()
    labels: list[str] = []
    if filters.query:
        labels.append(f'Search “{filters.query}”')
    if filters.author_id:
        name = next(
            (str(row["name"]) for row in authors if row["openalex_id"] == filters.author_id),
            filters.author_id,
        )
        labels.append(f"Author: {name}")
    if filters.author_tags:
        author_names = {
            str(row["openalex_id"]): str(row["name"])
            for row in authors
            if row["openalex_id"]
        }
        selected_authors = [
            author_names.get(short_openalex_id(value) or value, value)
            for value in filters.author_tags
        ]
        labels.append(f"Authors: {', '.join(selected_authors)}")
    if filters.topic_id:
        name = next(
            (
                str(row["display_name"])
                for row in topics
                if row["openalex_id"] == filters.topic_id
            ),
            filters.topic_id,
        )
        labels.append(f"Topic: {name}")
    if filters.paper_kind:
        labels.append(f"Kind: {filters.paper_kind.replace('_', ' ')}")
    if filters.scope:
        labels.append(f"Scope: {filters.scope}")
    if filters.has_pdf is not None:
        labels.append("PDF available" if filters.has_pdf else "PDF missing")
    if filters.analyzed is not None:
        labels.append("Analyzed" if filters.analyzed else "Not analyzed")
    if filters.date_from:
        labels.append(f"From {filters.date_from}")
    if filters.date_to:
        labels.append(f"To {filters.date_to}")
    selection["labels"] = labels
    return selection


def _query_output(row: Any) -> dict[str, Any]:
    data = _row_dict(row)
    data["output"] = _json_value(data.get("output_json"), None)
    selection = _json_value(data.get("selection_json"), {})
    data["selection"] = selection if isinstance(selection, dict) else {}
    selection_items = []
    labels = data["selection"].get("labels")
    if isinstance(labels, list):
        selection_items.extend(str(item) for item in labels if item)
    if not selection_items:
        query = str(data["selection"].get("query") or "")
        if query:
            selection_items.append(f'Search “{query}”')
        if data["selection"].get("date_from"):
            selection_items.append(f'From {data["selection"]["date_from"]}')
        if data["selection"].get("date_to"):
            selection_items.append(f'To {data["selection"]["date_to"]}')
    content_type = str(data["selection"].get("content_type") or "papers")
    source_scope = str(
        data["selection"].get("source_scope")
        or ("blog" if content_type == "blogs" else "abstract")
    )
    pdf_strategy = str(data["selection"].get("pdf_strategy") or "auto")
    selection_items.append(f"Source: {source_scope}")
    if source_scope == "fulltext":
        selection_items.append(f"PDF strategy: {pdf_strategy}")
    data["selection_label"] = " · ".join(selection_items) or "All matching records"
    raw_tags = data["selection"].get("author_tags")
    author_tags = raw_tags if isinstance(raw_tags, list) else []
    selection_pairs = [
        ("q", data["selection"].get("query")),
        ("author", data["selection"].get("author_id")),
        *(("author_tag", tag) for tag in author_tags if tag),
        ("topic", data["selection"].get("topic_id")),
        ("kind", data["selection"].get("paper_kind")),
        ("scope", data["selection"].get("scope")),
        ("has_pdf", _bool_query(data["selection"].get("has_pdf"))),
        ("analyzed", _bool_query(data["selection"].get("analyzed"))),
        ("date_from", data["selection"].get("date_from")),
        ("date_to", data["selection"].get("date_to")),
        (
            "sort",
            data["selection"].get("sort")
            if data["selection"].get("sort") != "newest"
            else "",
        ),
    ]
    selection_query = urlencode([(key, value) for key, value in selection_pairs if value])
    if content_type == "blogs":
        data["selection_url"] = "/blogs"
    else:
        data["selection_url"] = f"/?{selection_query}" if selection_query else "/"
    return data


def _csv_response(records: Iterable[dict[str, Any]]) -> Response:
    stream = io.StringIO(newline="")
    fields = [
        "id",
        "title",
        "publication_date",
        "authors",
        "topics",
        "venue",
        "doi",
        "arxiv_id",
        "openalex_id",
        "abstract",
        "publication_url",
        "pdf_url",
        "local_pdf_path",
        "analysis_scope",
        "paper_kind",
        "one_sentence_summary",
        "abstract_summary",
        "research_problem",
        "key_contributions",
        "limitations_and_open_questions",
    ]
    writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for record in records:
        author_names = [item.get("name", "") for item in record.get("authors", [])]
        analyses = record.get("analyses") or [None]
        for analysis in analyses:
            analysis = analysis or {}
            writer.writerow(
                {
                    **record,
                    "authors": "; ".join(author_names),
                    "topics": "; ".join(
                        item.get("display_name", item.get("name", ""))
                        for item in record.get("topics", [])
                    ),
                    "analysis_scope": analysis.get("scope", ""),
                    "paper_kind": analysis.get("paper_kind", ""),
                    "one_sentence_summary": analysis.get("one_sentence_summary", ""),
                    "abstract_summary": analysis.get("abstract_summary", ""),
                    "research_problem": analysis.get("research_problem", ""),
                    "key_contributions": json.dumps(
                        analysis.get("key_contributions", []), ensure_ascii=False
                    ),
                    "limitations_and_open_questions": json.dumps(
                        analysis.get("limitations_and_open_questions", []), ensure_ascii=False
                    ),
                }
            )
    return Response(
        stream.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="paperwatch-papers.csv"'},
    )


def create_app(
    config_path: str | Path = "config.toml",
    *,
    run_controller: RunController | None = None,
    analysis_controller: AnalysisController | None = None,
    query_controller: QueryController | None = None,
    author_client_factory: Callable[[AppConfig], Any] | None = None,
) -> FastAPI:
    config = load_config(config_path)
    controller = run_controller or RunController(config.config_path)
    model_controller = analysis_controller or AnalysisController(config.config_path)
    collection_controller = query_controller or QueryController(config.config_path)
    client_factory = author_client_factory or _author_client
    try:
        with analysis_lock(config.paths.database):
            with Database(config.paths.database) as recovery_db:
                recovery_db.fail_incomplete_query_runs(
                    "Interrupted because the web application restarted"
                )
                recovery_db.fail_incomplete_analysis_tasks(
                    "Interrupted because the web application restarted"
                )
    except AnalysisAlreadyInProgress:
        pass
    package_dir = Path(__file__).resolve().parent
    templates = Jinja2Templates(directory=str(package_dir / "web_templates"))
    templates.env.filters["fromjson"] = lambda value: _json_value(value, {})
    templates.env.filters["prettyjson"] = lambda value: json.dumps(
        value, ensure_ascii=False, indent=2, sort_keys=True
    )
    templates.env.filters["querystring"] = lambda items: urlencode(items)
    templates.env.filters["markdown"] = _render_stored_markdown

    app = FastAPI(title="paperwatch", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.config = config
    app.state.run_controller = controller
    app.state.analysis_controller = model_controller
    app.state.query_controller = collection_controller
    app.state.author_client_factory = client_factory
    app.mount("/static", StaticFiles(directory=str(package_dir / "web_static")), name="static")

    def render(request: Request, template: str, **context: Any) -> HTMLResponse:
        base = {
            "request": request,
            "config": config,
            "asset_version": __version__,
            "run_state": controller.snapshot(),
            "analysis_state": model_controller.snapshot(),
            "query_state": collection_controller.snapshot(),
            "notice": request.query_params.get("notice", "")[:300],
            "notice_level": request.query_params.get("level", "success"),
            "paper_kinds": PAPER_KINDS,
            "scopes": SCOPES,
            "page_sizes": PAGE_SIZES,
        }
        return templates.TemplateResponse(request, template, {**base, **context})

    @app.middleware("http")
    async def security_headers(request: Request, call_next: Callable[..., Any]) -> Response:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self'; img-src 'self' data: https: http:; "
            "script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
        )
        return response

    def _render_content_page(
        request: Request,
        *,
        default_content: str = "all",
        is_home: bool = False,
    ) -> HTMLResponse:
        filters = _parse_filters(request)
        content_filter = _content_kind(request.query_params.get("content"), default_content)
        selected_query_id = _int_or_none(request.query_params.get("query_id"))
        with Database(config.paths.database) as db:
            paper_rows: list[Any] = []
            blog_rows: list[Any] = []
            if content_filter != "blogs":
                paper_rows, _paper_total = db.search_papers(
                    query=filters.query,
                    title_query=filters.title_query,
                    author_id=filters.author_id,
                    author_ids=filters.author_ids,
                    author_tags=filters.author_tags,
                    content_tags=filters.content_tags,
                    topic_id=filters.topic_id,
                    topic_ids=filters.topic_ids,
                    paper_kind=filters.paper_kind,
                    scope=filters.scope,
                    has_pdf=filters.has_pdf,
                    analyzed=filters.analyzed,
                    starred=filters.starred,
                    read=filters.read,
                    selected=False,
                    date_from=filters.date_from,
                    date_to=filters.date_to,
                    sort=filters.sort,
                    limit=None,
                    offset=0,
                )
            blog_compatible_filters = not (
                filters.topic_id
                or filters.topic_ids
                or filters.paper_kind
                or filters.scope
                or filters.has_pdf is True
            )
            if content_filter != "papers" and blog_compatible_filters:
                blog_rows = db.list_blog_entries(
                    limit=None,
                    query=filters.query,
                    title_query=filters.title_query,
                    tags=filters.content_tags,
                    author_id=filters.author_id,
                    author_ids=filters.author_ids,
                    author_tags=filters.author_tags,
                    date_from=filters.date_from,
                    date_to=filters.date_to,
                    sort=filters.sort,
                    starred=filters.starred,
                    read=filters.read,
                    selected=False,
                    analyzed=filters.analyzed,
                )
            selected_paper_rows, _ = db.search_papers(
                selected=True, limit=None, offset=0, sort="discovered"
            )
            selected_blog_rows = db.list_blog_entries(
                limit=None, selected=True, sort="discovered"
            )
            author_rows = db.list_authors_with_tags(tracked_only=True)
            tag_rows = db.list_tags()
            content_tag_rows = db.list_content_tags()
            topic_rows = db.list_topics()
            saved_queries = [_query_view(row, config) for row in db.list_saved_queries()]
            paper_views = [_paper_table_view(db, row) for row in paper_rows]
            selected_paper_views = [_paper_table_view(db, row) for row in selected_paper_rows]
            blog_views = []
            for row in blog_rows:
                entry = dict(row)
                entry["tracked_authors"] = [
                    {
                        "name": str(author["name"]),
                        "url": f"/authors/{quote_plus(str(author['openalex_id']))}/blogs",
                    }
                    for author in db.blog_authors(int(entry["blog_id"]))
                ]
                entry["source_site"], entry["source_site_url"] = _website_view(
                    str(entry.get("source_url") or entry.get("url") or "")
                )
                blog_views.append(entry)
            selected_blog_views = []
            for row in selected_blog_rows:
                entry = dict(row)
                entry["tracked_authors"] = [
                    {
                        "name": str(author["name"]),
                        "url": f"/authors/{quote_plus(str(author['openalex_id']))}/blogs",
                    }
                    for author in db.blog_authors(int(entry["blog_id"]))
                ]
                entry["source_site"], entry["source_site_url"] = _website_view(
                    str(entry.get("source_url") or entry.get("url") or "")
                )
                selected_blog_views.append(entry)

        records: list[dict[str, Any]] = []
        for paper in paper_views:
            paper["content_type"] = "paper"
            paper["record_date"] = paper.get("publication_date") or paper.get("discovered_at") or ""
            paper["record_fetched"] = paper.get("fetched_at") or paper.get("discovered_at") or ""
            records.append(paper)
        for entry in blog_views:
            entry["content_type"] = "blog"
            entry["record_date"] = entry.get("published_at") or entry.get("fetched_at") or ""
            entry["record_fetched"] = entry.get("fetched_at") or ""
            records.append(entry)

        selected_records: list[dict[str, Any]] = []
        for paper in selected_paper_views:
            paper["content_type"] = "paper"
            paper["record_date"] = paper.get("publication_date") or paper.get("discovered_at") or ""
            paper["record_fetched"] = paper.get("fetched_at") or paper.get("discovered_at") or ""
            selected_records.append(paper)
        for entry in selected_blog_views:
            entry["content_type"] = "blog"
            entry["record_date"] = entry.get("published_at") or entry.get("fetched_at") or ""
            entry["record_fetched"] = entry.get("fetched_at") or ""
            selected_records.append(entry)
        selected_records.sort(
            key=lambda item: _record_sort_key(item, "discovered"), reverse=True
        )

        reverse = filters.sort not in {"oldest", "title"}
        records.sort(key=lambda item: _record_sort_key(item, filters.sort), reverse=reverse)
        total = len(records)
        pages = max(1, (total + filters.page_size - 1) // filters.page_size)
        if filters.page > pages and total:
            items = filters.query_items(page=pages)
            if content_filter != "all":
                items.append(("content", content_filter))
            return RedirectResponse(f"/?{urlencode(items)}", status_code=303)
        offset = (filters.page - 1) * filters.page_size
        records = records[offset : offset + filters.page_size]
        visible_papers = [item for item in records if item["content_type"] == "paper"]
        visible_blogs = [item for item in records if item["content_type"] == "blog"]
        previous_items = filters.query_items(page=filters.page - 1)
        next_items = filters.query_items(page=filters.page + 1)
        page_jump_items = filters.selection_items()
        if filters.page_size != DEFAULT_PAGE_SIZE:
            page_jump_items.append(("page_size", str(filters.page_size)))
        if content_filter != "all":
            previous_items.append(("content", content_filter))
            next_items.append(("content", content_filter))
            page_jump_items.append(("content", content_filter))
        return render(
            request,
            "content.html",
            records=records,
            selected_records=selected_records,
            selected_count=len(selected_records),
            papers=visible_papers,
            blog_entries=visible_blogs,
            filters=filters,
            content_filter=content_filter,
            authors=author_rows,
            author_tags=tag_rows,
            content_tags=content_tag_rows,
            topics=topic_rows,
            saved_queries=saved_queries,
            paper_queries=[query for query in saved_queries if _query_supports(query, "papers")],
            blog_queries=[query for query in saved_queries if _query_supports(query, "blogs")],
            selected_query_id=selected_query_id,
            model_profiles=config.available_llms,
            total=total,
            paper_total=len(paper_views),
            blog_total=len(blog_rows),
            pages=pages,
            is_home=is_home,
            previous_query=urlencode(previous_items),
            next_query=urlencode(next_items),
            page_jump_items=page_jump_items,
        )

    @app.get("/", response_class=HTMLResponse)
    def recent_papers(request: Request) -> HTMLResponse:
        return _render_content_page(request, default_content="all", is_home=True)

    @app.post("/content/{content_type}/{record_id}/star")
    async def star_content(
        request: Request, content_type: str, record_id: int
    ) -> Response:
        form = await request.form()
        starred = str(form.get("starred", "")) in {"1", "true", "on"}
        with Database(config.paths.database) as db:
            if not db.set_content_starred(content_type, record_id, starred):
                raise HTTPException(404, "Content not found")
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True, "starred": starred})
        return RedirectResponse(_request_return_path(request), status_code=303)

    @app.post("/content/{content_type}/{record_id}/read")
    async def read_content(
        request: Request, content_type: str, record_id: int
    ) -> Response:
        form = await request.form()
        read = str(form.get("read", "1")) in {"1", "true", "on"}
        with Database(config.paths.database) as db:
            if not db.set_content_read(content_type, record_id, read):
                raise HTTPException(404, "Content not found")
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True, "read": read})
        return RedirectResponse(_request_return_path(request), status_code=303)

    @app.post("/content/{content_type}/{record_id}/select")
    async def select_content(
        request: Request, content_type: str, record_id: int
    ) -> Response:
        form = await request.form()
        selected = str(form.get("selected", "")) in {"1", "true", "on"}
        with Database(config.paths.database) as db:
            if not db.set_content_selected(content_type, record_id, selected):
                raise HTTPException(404, "Content not found")
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True, "selected": selected})
        return RedirectResponse(_request_return_path(request), status_code=303)

    @app.post("/content/selected/{action}")
    def update_selected_content(request: Request, action: str) -> Response:
        try:
            with Database(config.paths.database) as db:
                changed = db.bulk_update_selected_content(action)
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            raise HTTPException(400, str(exc)) from exc
        if _async_request(request):
            return JSONResponse({"ok": True, "changed": changed})
        return RedirectResponse(_request_return_path(request), status_code=303)

    @app.post("/content/selected/tags/{action}")
    async def update_selected_tags(request: Request, action: str) -> Response:
        form = await request.form()
        try:
            with Database(config.paths.database) as db:
                changed, action_id = db.bulk_update_selected_tags(
                    action, str(form.get("tag", ""))
                )
        except ValueError as exc:
            if request.headers.get("X-Paperwatch-Async") == "1":
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(
                _notice_url(_request_return_path(request), str(exc), level="error"),
                status_code=303,
            )
        payload = {"ok": True, "changed": changed, "action_id": action_id}
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse(payload)
        return RedirectResponse(
            _notice_url(_request_return_path(request), f"Updated {changed} tag link(s)."),
            status_code=303,
        )

    @app.post("/tags/remove-global")
    async def remove_global_tag(request: Request) -> Response:
        form = await request.form()
        try:
            with Database(config.paths.database) as db:
                changed, action_id = db.remove_tag_globally(
                    str(form.get("tag", "")), str(form.get("scope", "all"))
                )
        except ValueError as exc:
            if request.headers.get("X-Paperwatch-Async") == "1":
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(
                _notice_url(_request_return_path(request), str(exc), level="error"),
                status_code=303,
            )
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True, "changed": changed, "action_id": action_id})
        return RedirectResponse(
            _notice_url(_request_return_path(request), f"Removed {changed} tag link(s)."),
            status_code=303,
        )

    @app.post("/tags/undo")
    async def undo_tag_action(request: Request) -> Response:
        with Database(config.paths.database) as db:
            changed = db.undo_last_tag_action()
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True, "changed": changed})
        return RedirectResponse(
            _notice_url(_request_return_path(request), f"Restored {changed} tag link(s)."),
            status_code=303,
        )

    @app.post("/notes/{object_type}/{object_id}")
    async def save_object_notes(
        request: Request, object_type: str, object_id: int
    ) -> Response:
        form = await request.form()
        try:
            with Database(config.paths.database) as db:
                if not db.set_object_notes(object_type, object_id, str(form.get("notes", ""))):
                    raise HTTPException(404, "Object not found")
        except ValueError as exc:
            if request.headers.get("X-Paperwatch-Async") == "1":
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(
                _notice_url(_request_return_path(request), str(exc), level="error"),
                status_code=303,
            )
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True})
        return RedirectResponse(_request_return_path(request), status_code=303)

    @app.get("/exports/authors.csv")
    def export_authors_csv() -> Response:
        output = io.StringIO(newline="")
        fields = ["Author Name", "Institution", "OpenAlex ID", "Starred", "Enabled", "Tags", "Notes"]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        with Database(config.paths.database) as db:
            for row in db.list_authors_with_tags(tracked_only=True):
                writer.writerow({
                    "Author Name": row["name"],
                    "Institution": row["institution"] or "",
                    "OpenAlex ID": "" if str(row["openalex_id"]).startswith("LOCAL-") else row["openalex_id"],
                    "Starred": "yes" if row["starred"] else "no",
                    "Enabled": "yes" if row["enabled"] else "no",
                    "Tags": row["tags"] or "",
                    "Notes": row["notes"] or "",
                })
        return Response(output.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="paperwatch-authors.csv"'})

    @app.get("/exports/blogs.csv")
    def export_blogs_csv() -> Response:
        output = io.StringIO(newline="")
        fields = [
            "Researcher / author", "Current lab / organization",
            "Primary applied-ML source", "Primary source URL", "Relationship to author",
            "Primary source type", "Primary source mode", "Primary content selector",
            "Primary article URL pattern", "Primary tags", "Notes", "Enabled",
        ]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        with Database(config.paths.database) as db:
            for author in db.list_authors(tracked_only=True):
                for blog in db.author_blogs(str(author["openalex_id"])):
                    writer.writerow({
                        "Researcher / author": author["name"],
                        "Current lab / organization": author["institution"] or "",
                        "Primary applied-ML source": blog["label"] or blog["title"] or "",
                        "Primary source URL": blog["url"],
                        "Relationship to author": blog["relationship"] or "",
                        "Primary source type": blog["item_stream_mode"] or "",
                        "Primary source mode": blog["source_mode"] or "auto",
                        "Primary content selector": blog["content_selector"] or "",
                        "Primary article URL pattern": blog["article_url_pattern"] or "",
                        "Primary tags": blog["source_tags"] or "",
                        "Notes": blog["notes"] or "",
                        "Enabled": "yes" if blog["enabled"] else "no",
                    })
        return Response(output.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="paperwatch-blogs.csv"'})

    @app.get("/authors", response_class=HTMLResponse)
    def authors(request: Request) -> HTMLResponse:
        tag = request.query_params.get("tag", "").strip()[:40]
        name = request.query_params.get("name", "").strip()[:200]
        query = request.query_params.get("q", "").strip()[:200]
        starred = _parse_tristate(request.query_params.get("starred"))
        with Database(config.paths.database) as db:
            rows = [dict(row) for row in db.list_authors_with_tags(
                tracked_only=True, tag=tag, query=query, starred=starred
            )]
            for row in rows:
                row["is_local"] = str(row["openalex_id"]).startswith("LOCAL-")
            tags = db.list_tags()
        return render(
            request,
            "authors.html",
            authors=rows,
            tags=tags,
            active_tag=tag,
            author_query=query,
            author_starred=starred,
        )

    @app.post("/authors/manual")
    async def add_manual_author(request: Request) -> RedirectResponse:
        form = await request.form()
        name = clean_text(str(form.get("name", ""))) or ""
        institution = clean_text(str(form.get("institution", "")))
        try:
            if not name:
                raise ValueError("Author name is required")
            openalex_id = _manual_openalex_author_id(str(form.get("openalex_id", "")))
            with Database(config.paths.database) as db:
                if openalex_id:
                    author_db_id = db.add_author(
                        AuthorCandidate(
                            openalex_id=openalex_id,
                            name=name,
                            institution=institution,
                            metadata={"manual": True},
                        )
                    )
                    identifier = openalex_id
                else:
                    author_db_id = db.add_manual_author(name, institution)
                    author_row = db.find_authors_by_name(name)[0]
                    identifier = str(author_row["openalex_id"])
                for tag in _split_tags(str(form.get("tags", ""))):
                    db.add_author_tag(identifier, tag)
                db.set_object_notes("author", author_db_id, str(form.get("notes", "")))
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/authors", str(exc), level="error"), status_code=303
            )
        suffix = " Papers are paused until an OpenAlex ID is provided." if not openalex_id else ""
        return RedirectResponse(
            _notice_url("/authors", f"Added {name}.{suffix}"), status_code=303
        )

    @app.post("/authors/blogs/manual")
    async def import_single_author_blog(request: Request) -> RedirectResponse:
        form = await request.form()
        openalex_id = str(form.get("openalex_id", "")).strip()
        try:
            if not openalex_id:
                raise ValueError("Choose an author")
            url = normalize_blog_url(str(form.get("url", "")))
            with Database(config.paths.database) as db:
                blog_id = db.add_author_blog(openalex_id, url)
                for tag in _split_tags(str(form.get("tags", ""))):
                    db.add_blog_source_tag(blog_id, tag)
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/authors", str(exc), level="error"), status_code=303
            )
        return RedirectResponse(
            _notice_url("/authors", "Blog linked."), status_code=303
        )

    @app.post("/authors/blogs/import")
    async def import_author_blogs(request: Request) -> RedirectResponse:
        form = await request.form()
        upload = form.get("csv_file")
        create_missing = str(form.get("create_missing", "")) in {"1", "true", "on"}
        import_tags = _split_tags(str(form.get("import_tags", "")))
        if not isinstance(upload, UploadFile) or not upload.filename:
            return RedirectResponse(
                _notice_url("/authors", "Choose a CSV file.", level="error"),
                status_code=303,
            )
        try:
            raw = await upload.read(5_000_001)
            if len(raw) > 5_000_000:
                raise ValueError("CSV file exceeds 5 MB")
            text = raw.decode("utf-8-sig")
            with Database(config.paths.database) as db:
                stats = import_blog_links(
                    db,
                    io.StringIO(text, newline=""),
                    create_missing=create_missing,
                    import_tags=import_tags,
                )
        except (UnicodeDecodeError, ValueError) as exc:
            return RedirectResponse(
                _notice_url("/authors", f"Could not import blogs: {exc}", level="error"),
                status_code=303,
            )
        finally:
            await upload.close()
        message = (
            f"Imported {stats.links} blog links; created {stats.authors_created} authors, "
            f"skipped {stats.authors_missing} missing and {stats.authors_ambiguous} ambiguous authors."
        )
        return RedirectResponse(_notice_url("/authors", message), status_code=303)

    @app.post("/authors/import")
    async def import_authors_csv(request: Request) -> RedirectResponse:
        form = await request.form()
        upload = form.get("csv_file")
        if not isinstance(upload, UploadFile) or not upload.filename:
            return RedirectResponse(
                _notice_url("/authors", "Choose an author CSV file.", level="error"),
                status_code=303,
            )
        imported = 0
        import_tags = _split_tags(str(form.get("import_tags", "")))
        try:
            raw = await upload.read(5_000_001)
            if len(raw) > 5_000_000:
                raise ValueError("CSV file exceeds 5 MB")
            stream = io.StringIO(raw.decode("utf-8-sig"), newline="")
            reader = csv.DictReader(stream, skipinitialspace=True)
            if reader.fieldnames:
                reader.fieldnames = [(name or "").strip() for name in reader.fieldnames]
            fields = {str(name).casefold(): str(name) for name in (reader.fieldnames or ())}
            name_column = next(
                (
                    fields[key]
                    for key in ("author name", "name", "researcher / author")
                    if key in fields
                ),
                None,
            )
            if name_column is None:
                raise ValueError("CSV must contain an Author Name column")
            institution_column = next(
                (fields[key] for key in ("institution", "current lab / organization") if key in fields),
                None,
            )
            openalex_column = next(
                (fields[key] for key in ("openalex id", "openalex author id") if key in fields),
                None,
            )
            starred_column = fields.get("starred")
            enabled_column = fields.get("enabled")
            tags_column = fields.get("tags")
            notes_column = next((fields[key] for key in ("notes", "comments") if key in fields), None)
            with Database(config.paths.database) as db:
                for raw_row in reader:
                    row = {str(key).strip(): str(value or "").strip() for key, value in raw_row.items()}
                    name = clean_text(row.get(name_column)) or ""
                    if not name:
                        continue
                    institution = clean_text(row.get(institution_column)) if institution_column else None
                    openalex_id = _manual_openalex_author_id(
                        row.get(openalex_column, "") if openalex_column else ""
                    )
                    if openalex_id:
                        db.add_author(
                            AuthorCandidate(
                                openalex_id=openalex_id,
                                name=name,
                                institution=institution,
                                metadata={"csv_import": True},
                            )
                        )
                        identifier = openalex_id
                    else:
                        db.add_manual_author(name, institution)
                        matches = db.find_authors_by_name(name)
                        identifier = str(matches[0]["openalex_id"]) if matches else ""
                    if identifier and starred_column:
                        db.set_author_starred(
                            identifier,
                            row.get(starred_column, "").casefold() in {"1", "true", "yes", "on", "starred"},
                        )
                    if identifier and enabled_column:
                        db.set_author_enabled(
                            identifier,
                            row.get(enabled_column, "yes").casefold() not in {"0", "false", "no", "off", "disabled"},
                        )
                    if identifier:
                        for tag in (*import_tags, *_split_tags(row.get(tags_column, "") if tags_column else "")):
                            db.add_author_tag(identifier, tag)
                    if identifier and notes_column:
                        stored_author = db.get_author(identifier)
                        if stored_author is not None:
                            db.set_object_notes(
                                "author", int(stored_author["id"]), row.get(notes_column, "")
                            )
                    imported += 1
        except (UnicodeDecodeError, ValueError) as exc:
            return RedirectResponse(
                _notice_url("/authors", f"Could not import authors: {exc}", level="error"),
                status_code=303,
            )
        finally:
            await upload.close()
        return RedirectResponse(
            _notice_url("/authors", f"Imported {imported} author row{'s' if imported != 1 else ''}."),
            status_code=303,
        )

    @app.get("/authors/{openalex_id}/blogs", response_class=HTMLResponse)
    def author_blogs(request: Request, openalex_id: str) -> HTMLResponse:
        tag = request.query_params.get("tag", "").strip()[:80]
        with Database(config.paths.database) as db:
            author = db.get_author(openalex_id)
            if author is None or not author["tracked"]:
                raise HTTPException(404, "Author not found")
            blogs = db.author_blogs(openalex_id, tag=tag)
            content_tags = db.list_content_tags()
        return render(
            request,
            "author_blogs.html",
            author=author,
            blogs=blogs,
            active_tag=tag,
            content_tags=content_tags,
            source_modes=sorted(SOURCE_MODES),
        )

    @app.post("/authors/{openalex_id}/blogs")
    async def add_author_blog(request: Request, openalex_id: str) -> RedirectResponse:
        form = await request.form()
        try:
            url = normalize_blog_url(str(form.get("url", "")))
            label = str(form.get("label", ""))
            relationship = str(form.get("relationship", ""))
            source_mode = normalize_source_mode(form.get("source_mode", "auto"))
            content_selector = validate_content_selector(form.get("content_selector"))
            article_url_pattern = validate_article_url_pattern(
                form.get("article_url_pattern")
            )
            with Database(config.paths.database) as db:
                blog_id = db.add_author_blog(
                    openalex_id,
                    url,
                    label=label,
                    relationship=relationship,
                    source_mode=source_mode,
                    content_selector=content_selector,
                    article_url_pattern=article_url_pattern,
                )
                for tag in _split_tags(str(form.get("tags", ""))):
                    db.add_blog_source_tag(blog_id, tag)
        except ValueError as exc:
            return RedirectResponse(
                _notice_url(
                    f"/authors/{quote_plus(openalex_id)}/blogs",
                    str(exc),
                    level="error",
                ),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url(f"/authors/{quote_plus(openalex_id)}/blogs", "Blog linked."),
            status_code=303,
        )

    @app.post("/authors/{openalex_id}/blogs/{blog_id}/tags/add")
    async def add_blog_source_tag(
        request: Request, openalex_id: str, blog_id: int
    ) -> Response:
        form = await request.form()
        try:
            with Database(config.paths.database) as db:
                if not db.add_blog_source_tag(blog_id, str(form.get("tag", ""))):
                    raise HTTPException(404, "Blog source not found")
        except ValueError as exc:
            if request.headers.get("X-Paperwatch-Async") == "1":
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(
                _notice_url(f"/authors/{quote_plus(openalex_id)}/blogs", str(exc), level="error"),
                status_code=303,
            )
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True})
        return RedirectResponse(f"/authors/{quote_plus(openalex_id)}/blogs", status_code=303)

    @app.post("/authors/{openalex_id}/blogs/{blog_id}/tags/remove")
    async def remove_blog_source_tag(
        request: Request, openalex_id: str, blog_id: int
    ) -> Response:
        form = await request.form()
        with Database(config.paths.database) as db:
            db.remove_blog_source_tag(blog_id, str(form.get("tag", "")))
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True})
        return RedirectResponse(f"/authors/{quote_plus(openalex_id)}/blogs", status_code=303)

    @app.post("/authors/{openalex_id}/blogs/{blog_id}/remove")
    def remove_author_blog(openalex_id: str, blog_id: int) -> RedirectResponse:
        with Database(config.paths.database) as db:
            if not db.remove_author_blog(openalex_id, blog_id):
                raise HTTPException(404, "Blog link not found")
        return RedirectResponse(
            _notice_url(f"/authors/{quote_plus(openalex_id)}/blogs", "Blog unlinked."),
            status_code=303,
        )

    @app.post("/authors/{openalex_id}/blogs/{blog_id}/edit")
    async def edit_author_blog(
        request: Request, openalex_id: str, blog_id: int
    ) -> RedirectResponse:
        form = await request.form()
        try:
            url = normalize_blog_url(str(form.get("url", "")))
            source_mode = normalize_source_mode(form.get("source_mode", "auto"))
            content_selector = validate_content_selector(form.get("content_selector"))
            article_url_pattern = validate_article_url_pattern(
                form.get("article_url_pattern")
            )
            with Database(config.paths.database) as db:
                if not db.update_author_blog_url(
                    openalex_id,
                    blog_id,
                    url,
                    source_mode=source_mode,
                    content_selector=content_selector,
                    article_url_pattern=article_url_pattern,
                ):
                    raise HTTPException(404, "Blog link not found")
        except ValueError as exc:
            return RedirectResponse(
                _notice_url(
                    f"/authors/{quote_plus(openalex_id)}/blogs",
                    str(exc),
                    level="error",
                ),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url(
                f"/authors/{quote_plus(openalex_id)}/blogs",
                "Blog URL updated.",
            ),
            status_code=303,
        )

    @app.post("/authors/{openalex_id}/blogs/{blog_id}/availability")
    async def set_author_blog_availability(
        request: Request, openalex_id: str, blog_id: int
    ) -> RedirectResponse:
        form = await request.form()
        broken = str(form.get("broken", "")) in {"1", "true", "on"}
        with Database(config.paths.database) as db:
            if not db.set_author_blog_broken(openalex_id, blog_id, broken):
                raise HTTPException(404, "Blog link not found")
        message = (
            "Blog marked broken; future checks are paused."
            if broken
            else "Blog restored."
        )
        return RedirectResponse(
            _notice_url(f"/authors/{quote_plus(openalex_id)}/blogs", message),
            status_code=303,
        )

    @app.get("/blogs", response_class=HTMLResponse)
    def blog_feed(request: Request) -> HTMLResponse:
        return _render_content_page(request, default_content="blogs")

    @app.get("/blogs/import", response_class=HTMLResponse)
    def import_blog_entry_page(request: Request) -> HTMLResponse:
        with Database(config.paths.database) as db:
            authors = db.list_authors(tracked_only=True)
        return render(request, "import_blog_entry.html", authors=authors)

    @app.post("/blogs/import")
    async def import_blog_entry(request: Request) -> RedirectResponse:
        form = await request.form()
        author_id = str(form.get("author_id", "")).strip()
        title = clean_text(str(form.get("entry_title", "")))
        content = str(form.get("content", "")).strip()
        published_at = str(form.get("published_at", "")).strip()
        try:
            if not author_id:
                raise ValueError("Choose a tracked author")
            if not title:
                raise ValueError("Entry title is required")
            if not content:
                raise ValueError("Entry text is required")
            if len(title) > 1000:
                raise ValueError("Entry title is too long")
            if len(content) > 5_000_000:
                raise ValueError("Entry text is too long")
            blog_url = normalize_blog_url(str(form.get("blog_url", "")))
            entry_url = normalize_blog_url(str(form.get("entry_url", "")))
            if published_at:
                try:
                    datetime.fromisoformat(published_at.replace("Z", "+00:00"))
                except ValueError as exc:
                    raise ValueError("Published time must be ISO 8601") from exc
            normalized = f"Title: {title}\nURL: {entry_url}\n\n{content}"
            digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
            external_id = hashlib.sha256(
                f"manual\0{entry_url}".encode("utf-8")
            ).hexdigest()
            with Database(config.paths.database) as db:
                if db.get_author(author_id) is None:
                    raise ValueError("Tracked author was not found")
                blog_id = db.add_author_blog(
                    author_id,
                    blog_url,
                    label=str(form.get("blog_label", "")),
                    relationship=str(form.get("relationship", "Direct import")),
                    source_mode="article",
                )
                previous = db.latest_blog_entry(
                    blog_id, entry_kind="snapshot", external_id=external_id
                )
                if previous is not None and previous["content_sha256"] == digest:
                    entry_id = int(previous["id"])
                else:
                    kind, diff = blog_diff(
                        str(previous["normalized_text"]) if previous is not None else None,
                        normalized,
                    )
                    entry_id = db.save_blog_entry(
                        blog_id=blog_id,
                        title=title,
                        content_sha256=digest,
                        normalized_text=normalized,
                        diff_text=diff,
                        change_kind="changed" if previous is None else kind,
                        previous_entry_id=int(previous["id"]) if previous is not None else None,
                        entry_kind="snapshot",
                        external_id=external_id,
                        source_url=entry_url,
                        published_at=published_at or None,
                    )
                for tag in _split_tags(str(form.get("tags", ""))):
                    db.add_blog_entry_tag(entry_id, tag)
                if str(form.get("notes", "")).strip():
                    db.set_object_notes("blog", entry_id, str(form.get("notes", "")))
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/blogs/import", str(exc), level="error"), status_code=303
            )
        return RedirectResponse(
            _notice_url(f"/blogs/{entry_id}", "Blog entry imported."), status_code=303
        )

    @app.get("/blogs/{entry_id}", response_class=HTMLResponse)
    def blog_entry(request: Request, entry_id: int) -> HTMLResponse:
        with Database(config.paths.database) as db:
            entry = db.get_blog_entry(entry_id)
            saved_queries = [
                query for row in db.list_saved_queries()
                if _query_supports(query := _query_view(row, config), "blogs")
            ]
            prompt_runs = [
                _query_output(row) for row in db.query_runs_for_blog_entry(entry_id)
            ]
            entry_tags = db.blog_entry_tags(entry_id)
            content_tags = db.list_content_tags()
            tracked_authors = db.blog_authors(int(entry["blog_id"])) if entry else []
            classifications = db.classification_results_for_content("blog", entry_id)
        if entry is None:
            raise HTTPException(404, "Blog update not found")
        entry_view = dict(entry)
        entry_view["tracked_authors"] = [
            {
                "name": str(author["name"]),
                "url": f"/authors/{quote_plus(str(author['openalex_id']))}/blogs",
                "entries_url": f"/?content=blogs&author={quote_plus(str(author['openalex_id']))}",
            }
            for author in tracked_authors
        ]
        entry_view["display_html"] = str(entry["rendered_html"] or "") or _render_stored_markdown(
            str(entry["normalized_text"] or "")
        )
        return render(
            request,
            "blog_detail.html",
            entry=entry_view,
            saved_queries=saved_queries,
            prompt_runs=prompt_runs,
            model_profiles=config.available_llms,
            entry_tags=entry_tags,
            content_tags=content_tags,
            classifications=classifications,
        )

    @app.post("/blogs/{entry_id}/prompt")
    async def prompt_blog_entry(request: Request, entry_id: int) -> Response:
        async_request = request.headers.get("x-paperwatch-async") == "1"
        form = await request.form()
        query_id = _int_or_none(form.get("query_id"))
        profiles = tuple(str(value) for value in form.getlist("model") if str(value))
        context = _int_or_none(form.get("context_window_tokens")) or DEFAULT_CONTEXT_WINDOW_TOKENS
        with Database(config.paths.database) as db:
            entry = db.get_blog_entry(entry_id)
            query = db.get_saved_query(query_id) if query_id is not None else None
        if entry is None:
            raise HTTPException(404, "Blog update not found")

        def failure(message: str, status_code: int = 400) -> Response:
            if async_request:
                return JSONResponse({"ok": False, "message": message}, status_code=status_code)
            return RedirectResponse(
                _notice_url(f"/blogs/{entry_id}", message, level="error"), status_code=303
            )

        if query is None:
            return failure("Select a saved prompt.")
        try:
            batch_id = collection_controller.start(
                int(query["id"]),
                profiles,
                context,
                selection={
                    "content_type": "blogs",
                    "blog_entry_ids": [entry_id],
                    "labels": [f"Blog entry: {entry['title']}"],
                },
                source_scope="blog",
                pdf_strategy="auto",
                content_type="blogs",
            )
        except ValueError as exc:
            return failure(str(exc))
        if batch_id is None:
            return failure("Another saved prompt is already running.", status_code=409)
        message = f"Started {query['name']} with {len(set(profiles))} model(s)."
        if async_request:
            return JSONResponse({"ok": True, "batch_id": batch_id, "message": message})
        return RedirectResponse(_notice_url(f"/blogs/{entry_id}", message), status_code=303)

    @app.post("/blogs/{entry_id}/tags/add")
    async def add_blog_content_tag(request: Request, entry_id: int) -> Response:
        form = await request.form()
        tag = str(form.get("tag", ""))
        try:
            with Database(config.paths.database) as db:
                if not db.add_blog_entry_tag(entry_id, tag):
                    raise HTTPException(404, "Blog entry not found")
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(_notice_url(f"/blogs/{entry_id}", str(exc), level="error"), status_code=303)
        if _async_request(request):
            return JSONResponse({"ok": True, "tag": tag})
        return RedirectResponse(_notice_url(f"/blogs/{entry_id}", "Tag added."), status_code=303)

    @app.post("/blogs/{entry_id}/tags/remove")
    async def remove_blog_content_tag(request: Request, entry_id: int) -> Response:
        form = await request.form()
        tag = str(form.get("tag", ""))
        try:
            with Database(config.paths.database) as db:
                db.remove_blog_entry_tag(entry_id, tag)
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(_notice_url(f"/blogs/{entry_id}", str(exc), level="error"), status_code=303)
        if _async_request(request):
            return JSONResponse({"ok": True, "tag": tag})
        return RedirectResponse(f"/blogs/{entry_id}", status_code=303)

    @app.post("/content/{content_type}/{record_id}/classifications/{query_id}")
    async def update_content_classification(
        request: Request,
        content_type: str,
        record_id: int,
        query_id: int,
    ) -> Response:
        form = await request.form()
        value = str(form.get("value", ""))
        try:
            with Database(config.paths.database) as db:
                if not db.set_content_classification(query_id, content_type, record_id, value):
                    raise HTTPException(404, "Classification or content not found")
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(_notice_url(_request_return_path(request), str(exc), level="error"), status_code=303)
        if _async_request(request):
            return JSONResponse({"ok": True, "value": value})
        return RedirectResponse(_request_return_path(request), status_code=303)

    @app.post("/authors/search")
    async def search_authors(request: Request) -> RedirectResponse:
        form = await request.form()
        name = str(form.get("name", "")).strip()[:200]
        target = f"/discover?mode=author&q={quote_plus(name)}" if name else "/discover?mode=author"
        return RedirectResponse(target, status_code=303)

    @app.post("/authors/{openalex_id}/add")
    def add_author(openalex_id: str) -> RedirectResponse:
        client = client_factory(config)
        try:
            candidate = client.get_author(openalex_id)
        except Exception as exc:
            return RedirectResponse(
                _notice_url("/authors", f"Could not add author: {exc}", level="error"),
                status_code=303,
            )
        finally:
            client.close()
        with Database(config.paths.database) as db:
            db.add_author(candidate)
        return RedirectResponse(
            _notice_url("/authors", f"Added {candidate.name}."), status_code=303
        )

    @app.post("/authors/{openalex_id}/openalex-id")
    async def update_author_openalex_id(
        request: Request, openalex_id: str
    ) -> RedirectResponse:
        form = await request.form()
        try:
            replacement = _manual_openalex_author_id(
                str(form.get("openalex_id", ""))
            )
            if replacement is None:
                raise ValueError("OpenAlex author ID is required")
            with Database(config.paths.database) as db:
                if not db.update_author_openalex_id(openalex_id, replacement):
                    raise HTTPException(404, "Author not found")
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/authors", str(exc), level="error"), status_code=303
            )
        return RedirectResponse(
            _notice_url("/authors", f"OpenAlex ID updated to {replacement}."),
            status_code=303,
        )

    @app.post("/authors/{openalex_id}/enable")
    def enable_author(openalex_id: str) -> RedirectResponse:
        with Database(config.paths.database) as db:
            if not db.set_author_enabled(openalex_id, True):
                raise HTTPException(404, "Author not found")
        return RedirectResponse(_notice_url("/authors", "Author enabled."), status_code=303)

    @app.post("/authors/{openalex_id}/star")
    async def star_author(request: Request, openalex_id: str) -> Response:
        form = await request.form()
        starred = str(form.get("starred", "")) in {"1", "true", "on"}
        with Database(config.paths.database) as db:
            if not db.set_author_starred(openalex_id, starred):
                raise HTTPException(404, "Author not found")
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse({"ok": True, "starred": starred})
        return RedirectResponse(_request_return_path(request, "/authors"), status_code=303)

    @app.post("/authors/{openalex_id}/disable")
    def disable_author(openalex_id: str) -> RedirectResponse:
        with Database(config.paths.database) as db:
            if not db.set_author_enabled(openalex_id, False):
                raise HTTPException(404, "Author not found")
        return RedirectResponse(_notice_url("/authors", "Author disabled."), status_code=303)

    @app.post("/authors/{openalex_id}/remove")
    def remove_author(openalex_id: str) -> RedirectResponse:
        with Database(config.paths.database) as db:
            if not db.remove_author(openalex_id):
                raise HTTPException(404, "Author not found")
        return RedirectResponse(_notice_url("/authors", "Author removed from tracking; its database record was retained."), status_code=303)

    @app.post("/authors/{openalex_id}/tags")
    async def add_author_tag(request: Request, openalex_id: str) -> Response:
        form = await request.form()
        tag = str(form.get("tag", "")).strip()
        try:
            with Database(config.paths.database) as db:
                if not db.add_author_tag(openalex_id, tag):
                    raise HTTPException(404, "Author not found")
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(_notice_url("/authors", str(exc), level="error"), status_code=303)
        if _async_request(request):
            return JSONResponse({"ok": True, "tag": tag})
        return RedirectResponse(_notice_url("/authors", f"Added tag {tag}."), status_code=303)

    @app.post("/authors/{openalex_id}/tags/remove")
    async def remove_author_tag(request: Request, openalex_id: str) -> Response:
        form = await request.form()
        tag = str(form.get("tag", "")).strip()
        with Database(config.paths.database) as db:
            db.remove_author_tag(openalex_id, tag)
        if _async_request(request):
            return JSONResponse({"ok": True, "tag": tag})
        return RedirectResponse(_notice_url("/authors", f"Removed tag {tag}."), status_code=303)

    @app.get("/papers/import", response_class=HTMLResponse)
    def import_paper_form(request: Request) -> HTMLResponse:
        return render(
            request,
            "import_paper.html",
            import_values={},
            import_error="",
        )

    @app.post("/papers/import", response_class=HTMLResponse)
    async def import_paper(request: Request) -> Response:
        values: dict[str, str] = {}
        staged: Path | None = None
        backup: Path | None = None
        destination: Path | None = None
        upload: UploadFile | None = None
        try:
            form = await request.form(
                max_files=1,
                max_fields=20,
                max_part_size=config.fetch.max_pdf_bytes,
            )
            values = {
                key: str(form.get(key, ""))
                for key in (
                    "title",
                    "authors",
                    "source_link",
                    "abstract",
                    "publication_date",
                    "venue",
                    "doi",
                    "arxiv_id",
                    "tags",
                    "notes",
                )
            }
            form_upload = form.get("pdf")
            if not isinstance(form_upload, UploadFile) or not form_upload.filename:
                raise ValueError("PDF file is required")
            upload = form_upload
            paper = _manual_paper_record(values, filename=upload.filename)
            staged = await _stage_uploaded_pdf(
                upload,
                directory=config.paths.pdf_dir,
                max_bytes=config.fetch.max_pdf_bytes,
            )
            with Database(config.paths.database) as db:
                paper_id, _ = db.upsert_paper(paper, auto_analyze=True)
                stored = db.get_paper(paper_id)
                if stored is None:
                    raise RuntimeError("Imported paper could not be read back")
                destination = config.paths.pdf_dir / safe_pdf_name(
                    str(stored["identity_key"])
                )
            if destination.exists():
                backup = destination.with_suffix(
                    destination.suffix + f".backup-{uuid.uuid4().hex}"
                )
                destination.replace(backup)
            staged.replace(destination)
            staged = None
            with Database(config.paths.database) as db:
                db.set_local_pdf(paper_id, str(destination), pdf_sha256(destination))
                for tag in _split_tags(values.get("tags", "")):
                    db.add_paper_tag(paper_id, tag)
                if values.get("notes", "").strip():
                    db.set_object_notes("paper", paper_id, values["notes"])
            if backup is not None:
                backup.unlink(missing_ok=True)
            return RedirectResponse(
                _notice_url(
                    f"/papers/{paper_id}",
                    f"Imported {paper.title}.",
                ),
                status_code=303,
            )
        except Exception as exc:
            if destination is not None:
                if backup is not None and backup.exists():
                    destination.unlink(missing_ok=True)
                    backup.replace(destination)
                elif staged is None:
                    destination.unlink(missing_ok=True)
            response = render(
                request,
                "import_paper.html",
                import_values=values,
                import_error=str(exc),
            )
            response.status_code = 400
            return response
        finally:
            if upload is not None:
                await upload.close()
            if staged is not None:
                staged.unlink(missing_ok=True)
            if backup is not None:
                backup.unlink(missing_ok=True)

    @app.get("/discover", response_class=HTMLResponse)
    def discover(request: Request) -> HTMLResponse:
        requested_mode = request.query_params.get("mode", "").strip().lower()
        legacy_paper_query = request.query_params.get("paper_q", "").strip()[:500]
        legacy_author_query = request.query_params.get("author_q", "").strip()[:200]
        if requested_mode not in {"paper", "author"}:
            requested_mode = "author" if legacy_author_query and not legacy_paper_query else "paper"
        query_limit = 500 if requested_mode == "paper" else 200
        query = request.query_params.get("q", "").strip()[:query_limit]
        if not query:
            query = legacy_paper_query if requested_mode == "paper" else legacy_author_query
        paper_query = query if requested_mode == "paper" else ""
        author_query = query if requested_mode == "author" else ""
        limit = _int_or_none(request.query_params.get("limit")) or 100
        limit = min(max(limit, 1), 100)
        paper_results: list[PaperRecord] = []
        author_results: list[AuthorCandidate] = []
        paper_error = ""
        author_error = ""
        if paper_query or author_query:
            client = client_factory(config)
            try:
                if paper_query:
                    try:
                        paper_results = client.search_works(paper_query, limit=limit)
                    except Exception as exc:
                        paper_error = str(exc)
                if author_query:
                    try:
                        author_results = client.search_authors(author_query, limit=limit)
                    except Exception as exc:
                        author_error = str(exc)
            finally:
                client.close()
        return render(
            request,
            "discover.html",
            discover_mode=requested_mode,
            discover_query=query,
            paper_query=paper_query,
            author_query=author_query,
            search_limit=limit,
            paper_results=paper_results,
            author_results=author_results,
            paper_error=paper_error,
            author_error=author_error,
        )

    @app.get("/search")
    def search_papers(request: Request) -> RedirectResponse:
        query = request.query_params.get("q", "").strip()[:500]
        target = f"/discover?mode=paper&q={quote_plus(query)}" if query else "/discover?mode=paper"
        return RedirectResponse(target, status_code=303)

    @app.post("/actions/run")
    def start_run(request: Request) -> RedirectResponse:
        if controller.snapshot().running:
            controller.cancel()
        else:
            controller.start("run")
        referer = urlparse(request.headers.get("referer", ""))
        target = referer.path or "/"
        if referer.query:
            target = f"{target}?{referer.query}"
        return RedirectResponse(target, status_code=303)

    @app.post("/actions/download")
    async def download_paper(request: Request) -> RedirectResponse:
        form = await request.form()
        work_id = str(form.get("work_id", "")).strip()[:100]
        title = str(form.get("title", "")).strip()[:500]
        search_query = str(form.get("q", "")).strip()[:500]
        target = (
            f"/discover?mode=paper&q={quote_plus(search_query)}"
            if search_query
            else "/discover?mode=paper"
        )
        if not work_id:
            return RedirectResponse(
                _notice_url(target, "Paper identifier cannot be empty", level="error"),
                status_code=303,
            )
        parameters = inspect.signature(controller.start).parameters
        try:
            if "query" in parameters:
                started = controller.start("download", query=work_id)
            else:
                started = controller.start("download")
        except ValueError as exc:
            return RedirectResponse(
                _notice_url(target, str(exc), level="error"), status_code=303
            )
        if started:
            message = f"Downloading {title or work_id} and fetching linked blogs."
            level = "success"
        else:
            message = "A fetch is already running."
            level = "warning"
        return RedirectResponse(_notice_url(target, message, level=level), status_code=303)

    @app.post("/actions/backfill")
    def start_backfill() -> RedirectResponse:
        if controller.start("backfill"):
            message = (
                "One-year PDF backfill started. Historical papers will not be "
                "auto-summarized."
            )
            level = "success"
        else:
            message = "A fetch is already running."
            level = "warning"
        return RedirectResponse(_notice_url("/discover", message, level=level), status_code=303)

    @app.get("/api/run-status")
    def run_status() -> JSONResponse:
        return JSONResponse(asdict(controller.snapshot()))

    @app.get("/papers", response_class=HTMLResponse)
    def papers(request: Request) -> HTMLResponse:
        return _render_content_page(request, default_content="papers")

    @app.get("/papers/{paper_id}", response_class=HTMLResponse)
    def paper_detail(request: Request, paper_id: int) -> HTMLResponse:
        with Database(config.paths.database) as db:
            paper_row = db.get_paper(paper_id)
            if paper_row is None:
                raise HTTPException(404, "Paper not found")
            paper = _paper_pdf_state(db, _paper_view(paper_row))
            author_rows = [_author_view(row) for row in db.paper_authors(paper_id)]
            default_author_index = next(
                (index for index, author in enumerate(author_rows) if bool(author.get("is_tracked"))),
                0,
            )
            topic_rows = [dict(row) for row in db.paper_topics(paper_id)]
            analysis_tasks = [
                dict(row) for row in db.visible_analysis_tasks_for_paper(paper_id)
            ]
            analyses = [_analysis_view(row) for row in db.paper_analyses(paper_id)]
            saved_queries = [
                query for row in db.list_saved_queries()
                if _query_supports(query := _query_view(row, config), "papers")
            ]
            prompt_runs = [
                _query_output(row) for row in db.query_runs_for_paper(paper_id)
            ]
            paper_tags = db.paper_tags(paper_id)
            content_tags = db.list_content_tags()
            classifications = db.classification_results_for_content("paper", paper_id)
        return render(
            request,
            "paper_detail.html",
            paper=paper,
            authors=author_rows,
            default_author_index=default_author_index,
            topics=topic_rows,
            analysis_tasks=analysis_tasks,
            analyses=analyses,
            saved_queries=saved_queries,
            prompt_runs=prompt_runs,
            model_profiles=config.available_llms,
            metadata=_json_value(paper["metadata_json"], {}),
            paper_tags=paper_tags,
            content_tags=content_tags,
            classifications=classifications,
        )

    @app.post("/papers/{paper_id}/authors/{openalex_id}/add")
    def add_paper_author(paper_id: int, openalex_id: str) -> RedirectResponse:
        with Database(config.paths.database) as db:
            if db.get_paper(paper_id) is None:
                raise HTTPException(404, "Paper not found")
        with Database(config.paths.database) as db:
            existing = db.get_author(openalex_id)
            if existing is not None:
                db.set_author_enabled(openalex_id, True)
                name = str(existing["name"])
            else:
                client = client_factory(config)
                try:
                    candidate = client.get_author(openalex_id)
                except Exception as exc:
                    return RedirectResponse(
                        _notice_url(
                            f"/papers/{paper_id}",
                            f"Could not add author: {exc}",
                            level="error",
                        ),
                        status_code=303,
                    )
                finally:
                    client.close()
                db.add_author(candidate)
                name = candidate.name
        return RedirectResponse(
            _notice_url(f"/papers/{paper_id}", f"Added {name} to tracking."),
            status_code=303,
        )

    @app.post("/papers/{paper_id}/tags/add")
    async def add_paper_content_tag(request: Request, paper_id: int) -> Response:
        form = await request.form()
        tag = str(form.get("tag", ""))
        try:
            with Database(config.paths.database) as db:
                if not db.add_paper_tag(paper_id, tag):
                    raise HTTPException(404, "Paper not found")
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(_notice_url(f"/papers/{paper_id}", str(exc), level="error"), status_code=303)
        if _async_request(request):
            return JSONResponse({"ok": True, "tag": tag})
        return RedirectResponse(_notice_url(f"/papers/{paper_id}", "Tag added."), status_code=303)

    @app.post("/papers/{paper_id}/tags/remove")
    async def remove_paper_content_tag(request: Request, paper_id: int) -> Response:
        form = await request.form()
        tag = str(form.get("tag", ""))
        try:
            with Database(config.paths.database) as db:
                db.remove_paper_tag(paper_id, tag)
        except ValueError as exc:
            if _async_request(request):
                return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
            return RedirectResponse(_notice_url(f"/papers/{paper_id}", str(exc), level="error"), status_code=303)
        if _async_request(request):
            return JSONResponse({"ok": True, "tag": tag})
        return RedirectResponse(f"/papers/{paper_id}", status_code=303)

    @app.post("/papers/{paper_id}/analyze")
    async def analyze_paper(request: Request, paper_id: int) -> Response:
        async_request = request.headers.get("x-paperwatch-async") == "1"
        form = await request.form()
        scope = str(form.get("scope", "fulltext"))
        if scope not in SCOPES:
            raise HTTPException(400, "Invalid analysis scope")
        profile_names = tuple(str(value) for value in form.getlist("model"))
        strategy = str(form.get("strategy", "auto"))
        context_tokens = _int_or_none(form.get("context_window_tokens"))
        with Database(config.paths.database) as db:
            paper = db.get_paper(paper_id)
        if paper is None:
            raise HTTPException(404, "Paper not found")

        def failure(message: str, status_code: int = 400) -> Response:
            if async_request:
                return JSONResponse({"ok": False, "message": message}, status_code=status_code)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", message, level="error"), status_code=303
            )

        if scope == "abstract" and not paper["abstract"]:
            return failure("This paper has no abstract to analyze.")
        if scope == "fulltext" and not (paper["pdf_url"] or paper["local_pdf_path"]):
            return failure("This paper has no PDF available for full-text analysis.")
        try:
            if len(__import__("inspect").signature(model_controller.start).parameters) <= 3:
                batch_id = model_controller.start(paper_id, scope, profile_names)
            else:
                batch_id = model_controller.start(
                    paper_id, scope, profile_names, analysis_strategy=strategy,
                    context_window_tokens=context_tokens,
                )
        except ValueError as exc:
            return failure(str(exc))
        if batch_id is None:
            message = "Another model-analysis batch is already running."
            if async_request:
                return JSONResponse({"ok": False, "message": message}, status_code=409)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", message, level="warning"), status_code=303
            )
        message = f"Started {len(set(profile_names))} model analysis task(s)."
        if async_request:
            return JSONResponse({"ok": True, "batch_id": batch_id, "message": message})
        return RedirectResponse(
            _notice_url(f"/papers/{paper_id}#paper-jobs", message), status_code=303
        )

    @app.post("/papers/{paper_id}/prompt")
    async def prompt_paper(request: Request, paper_id: int) -> Response:
        async_request = request.headers.get("x-paperwatch-async") == "1"
        form = await request.form()
        query_id = _int_or_none(form.get("query_id"))
        profiles = tuple(str(value) for value in form.getlist("model") if str(value))
        context = _int_or_none(form.get("context_window_tokens")) or DEFAULT_CONTEXT_WINDOW_TOKENS
        source_scope = str(form.get("source_scope", "abstract"))
        pdf_strategy = str(form.get("pdf_strategy", "auto"))
        with Database(config.paths.database) as db:
            paper = db.get_paper(paper_id)
            query = db.get_saved_query(query_id) if query_id is not None else None
        if paper is None:
            raise HTTPException(404, "Paper not found")

        def failure(message: str, status_code: int = 400) -> Response:
            if async_request:
                return JSONResponse({"ok": False, "message": message}, status_code=status_code)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", message, level="error"), status_code=303
            )

        if query is None:
            return failure("Select a saved prompt.")
        if source_scope == "abstract" and not paper["abstract"]:
            return failure("This paper has no abstract to analyze.")
        if source_scope == "fulltext" and not (paper["pdf_url"] or paper["local_pdf_path"]):
            return failure("This paper has no PDF available for full-text analysis.")
        try:
            batch_id = collection_controller.start(
                int(query["id"]),
                profiles,
                context,
                selection={"paper_ids": [paper_id], "labels": [f"Paper: {paper['title']}"]},
                source_scope=source_scope,
                pdf_strategy=pdf_strategy,
            )
        except ValueError as exc:
            return failure(str(exc))
        if batch_id is None:
            message = "Another saved prompt is already running."
            if async_request:
                return JSONResponse({"ok": False, "message": message}, status_code=409)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", message, level="warning"), status_code=303
            )
        message = f"Started {query['name']} with {len(set(profiles))} model(s)."
        if async_request:
            return JSONResponse({"ok": True, "batch_id": batch_id, "message": message})
        return RedirectResponse(
            _notice_url(f"/papers/{paper_id}#paper-jobs", message), status_code=303
        )

    @app.get("/api/analysis-status")
    def analysis_status() -> JSONResponse:
        return JSONResponse(asdict(model_controller.snapshot()))

    @app.post("/api/analysis-cancel")
    def cancel_analysis() -> JSONResponse:
        cancelled = model_controller.cancel()
        return JSONResponse(
            {"ok": cancelled, "message": "Cancellation requested" if cancelled else "No analysis is running"},
            status_code=200 if cancelled else 409,
        )

    def local_pdf_path(paper_id: int) -> Path:
        with Database(config.paths.database) as db:
            paper = db.get_paper(paper_id)
        if paper is None or not paper["local_pdf_path"]:
            raise HTTPException(404, "Local PDF not found")
        path = Path(paper["local_pdf_path"]).expanduser().resolve()
        root = config.paths.pdf_dir.resolve()
        if not path.is_file() or (path != root and root not in path.parents):
            raise HTTPException(404, "Local PDF not found")
        return path

    @app.get("/papers/{paper_id}/pdf/open")
    def open_local_pdf(paper_id: int) -> Response:
        path = local_pdf_path(paper_id)
        opener = shutil.which("xdg-open")
        if opener is None:
            raise HTTPException(503, "xdg-open is not available")
        try:
            subprocess.Popen(
                [opener, str(path)],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except OSError as exc:
            raise HTTPException(500, f"Could not open PDF: {exc}") from exc
        return Response(status_code=204)

    @app.post("/papers/{paper_id}/pdf/upload")
    async def replace_local_pdf(request: Request, paper_id: int) -> RedirectResponse:
        upload: UploadFile | None = None
        staged: Path | None = None
        backup: Path | None = None
        destination: Path | None = None
        try:
            form = await request.form(
                max_files=1,
                max_fields=5,
                max_part_size=config.fetch.max_pdf_bytes,
            )
            candidate = form.get("pdf")
            if not isinstance(candidate, UploadFile) or not candidate.filename:
                raise ValueError("Choose a PDF file")
            upload = candidate
            staged = await _stage_uploaded_pdf(
                upload,
                directory=config.paths.pdf_dir,
                max_bytes=config.fetch.max_pdf_bytes,
            )
            with Database(config.paths.database) as db:
                paper = db.get_paper(paper_id)
                if paper is None:
                    raise HTTPException(404, "Paper not found")
                destination = config.paths.pdf_dir / safe_pdf_name(str(paper["identity_key"]))
            if destination.exists():
                backup = destination.with_suffix(destination.suffix + f".backup-{uuid.uuid4().hex}")
                destination.replace(backup)
            staged.replace(destination)
            staged = None
            with Database(config.paths.database) as db:
                db.set_local_pdf(paper_id, str(destination), pdf_sha256(destination))
            if backup is not None:
                backup.unlink(missing_ok=True)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", "Local PDF replaced."),
                status_code=303,
            )
        except (ValueError, PDFError, OSError) as exc:
            if destination is not None and backup is not None and backup.exists():
                destination.unlink(missing_ok=True)
                backup.replace(destination)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", str(exc), level="error"),
                status_code=303,
            )
        finally:
            if upload is not None:
                await upload.close()
            if staged is not None:
                staged.unlink(missing_ok=True)
            if backup is not None:
                backup.unlink(missing_ok=True)

    @app.post("/papers/{paper_id}/pdf/restore")
    def restore_local_pdf(paper_id: int) -> RedirectResponse:
        with Database(config.paths.database) as db:
            paper = db.get_paper(paper_id)
            if paper is None:
                raise HTTPException(404, "Paper not found")
            pdf_url = str(paper["pdf_url"] or "").strip()
            if not pdf_url:
                return RedirectResponse(
                    _notice_url(
                        f"/papers/{paper_id}",
                        "No remote PDF URL is stored for this paper.",
                        level="error",
                    ),
                    status_code=303,
                )
            destination = config.paths.pdf_dir / safe_pdf_name(str(paper["identity_key"]))
        backup = destination.with_suffix(destination.suffix + f".backup-{uuid.uuid4().hex}")
        try:
            if destination.exists():
                destination.replace(backup)
            download_pdf(
                pdf_url,
                destination,
                max_bytes=config.fetch.max_pdf_bytes,
            )
            validate_pdf_file(destination)
            with Database(config.paths.database) as db:
                db.set_local_pdf(paper_id, str(destination), pdf_sha256(destination))
            backup.unlink(missing_ok=True)
        except (PDFError, OSError) as exc:
            destination.unlink(missing_ok=True)
            if backup.exists():
                backup.replace(destination)
            return RedirectResponse(
                _notice_url(f"/papers/{paper_id}", str(exc), level="error"),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url(f"/papers/{paper_id}", "PDF restored from the remote source."),
            status_code=303,
        )

    @app.get("/papers/{paper_id}/pdf")
    def local_pdf(paper_id: int) -> FileResponse:
        path = local_pdf_path(paper_id)
        return FileResponse(
            path,
            media_type="application/pdf",
            filename=f"paper-{paper_id}.pdf",
            content_disposition_type="inline",
        )

    @app.get("/papers/{paper_id}/export.json")
    def export_paper(paper_id: int) -> JSONResponse:
        with Database(config.paths.database) as db:
            paper = db.get_paper(paper_id)
            if paper is None:
                raise HTTPException(404, "Paper not found")
            payload = _paper_export(db, paper)
        return JSONResponse(
            payload,
            headers={"Content-Disposition": f'attachment; filename="paper-{paper_id}.json"'},
        )

    @app.get("/analyses/{analysis_id}", response_class=HTMLResponse)
    def analysis_detail(request: Request, analysis_id: int) -> HTMLResponse:
        with Database(config.paths.database) as db:
            analysis_row = db.get_analysis_by_id(analysis_id)
            if analysis_row is None:
                raise HTTPException(404, "Analysis not found")
            paper_row = db.get_paper(int(analysis_row["paper_id"]))
            if paper_row is None:
                raise HTTPException(404, "Paper not found")
        return render(
            request,
            "analysis_detail.html",
            analysis=_analysis_view(analysis_row),
            paper=_paper_view(paper_row),
        )

    @app.get("/analyses/{analysis_id}/export.json")
    def export_analysis(analysis_id: int) -> JSONResponse:
        with Database(config.paths.database) as db:
            analysis = db.get_analysis_by_id(analysis_id)
        if analysis is None:
            raise HTTPException(404, "Analysis not found")
        return JSONResponse(
            _json_value(analysis["result_json"], {}),
            headers={
                "Content-Disposition": f'attachment; filename="analysis-{analysis_id}.json"'
            },
        )

    @app.get("/exports/papers.{format}")
    def export_papers(request: Request, format: str) -> Response:
        if format not in {"json", "jsonl", "csv"}:
            raise HTTPException(404, "Unknown export format")
        filters = _parse_filters(request)
        with Database(config.paths.database) as db:
            records = [_paper_export(db, row) for row in _all_filtered(db, filters)]
        if format == "csv":
            return _csv_response(records)
        if format == "jsonl":
            body = "".join(
                json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
                for record in records
            )
            return Response(
                body,
                media_type="application/x-ndjson",
                headers={"Content-Disposition": 'attachment; filename="paperwatch-papers.jsonl"'},
            )
        return JSONResponse(
            records,
            headers={"Content-Disposition": 'attachment; filename="paperwatch-papers.json"'},
        )

    @app.get("/queries", response_class=HTMLResponse)
    def queries(request: Request) -> HTMLResponse:
        with Database(config.paths.database) as db:
            saved = [_query_view(row, config) for row in db.list_saved_queries()]
            runs = [_query_output(row) for row in db.list_query_runs(limit=100)]
        runs_by_query: dict[int, list[dict[str, Any]]] = {}
        for row in runs:
            runs_by_query.setdefault(int(row["query_id"]), []).append(row)
        return render(
            request,
            "queries.html",
            queries=saved,
            runs=runs,
            runs_by_query=runs_by_query,
            model_profiles=config.available_llms,
        )

    @app.get("/queries/runs/{run_id}", response_class=HTMLResponse)
    def query_run_detail(request: Request, run_id: int) -> HTMLResponse:
        with Database(config.paths.database) as db:
            row = db.get_query_run(run_id)
            if row is None:
                raise HTTPException(404, "Query output not found")
            run = _query_output(row)
            selection = run.get("selection") if isinstance(run.get("selection"), dict) else {}
            links: list[dict[str, str]] = []
            blog_ids = selection.get("blog_entry_ids")
            if isinstance(blog_ids, list):
                for entry in db.blog_entries_by_ids(blog_ids):
                    links.append(
                        {
                            "label": f"Blog entry: {entry['title']}",
                            "url": f"/blogs/{int(entry['id'])}",
                        }
                    )
            paper_ids = selection.get("paper_ids")
            if isinstance(paper_ids, list):
                for raw_id in paper_ids:
                    paper_id = _int_or_none(raw_id)
                    paper = db.get_paper(paper_id) if paper_id is not None else None
                    if paper is not None:
                        links.append(
                            {
                                "label": f"Paper: {paper['title']}",
                                "url": f"/papers/{paper_id}",
                            }
                        )
            run["selection_links"] = links
            run["selection_source"] = str(
                selection.get("source_scope")
                or ("blog" if selection.get("content_type") == "blogs" else "abstract")
            )
        return render(request, "query_run_detail.html", run=run)

    @app.get("/queries/new", response_class=HTMLResponse)
    def query_new_page(request: Request) -> HTMLResponse:
        selected = [config.available_llms[0].profile] if config.available_llms else []
        query = {
            "name": "",
            "prompt": "",
            "is_builtin": False,
            "model_profiles": selected,
            "context_window_tokens": config.llm.context_window_tokens,
            "paper_source_scope": "auto",
            "pdf_strategy": "chunked",
            "regexp_pattern": "",
            "regexp_radius": 0,
            "regexp_mode": "query",
            "content_scope": "both",
            "query_kind": "summary",
            "label_class": "",
            "label_values": [],
            "label_values_text": "",
            "local_regexp": False,
        }
        return render(
            request,
            "query_edit.html",
            query=query,
            is_new=True,
            model_profiles=config.available_llms,
        )

    @app.get("/queries/{query_id}/edit", response_class=HTMLResponse)
    def query_edit_page(request: Request, query_id: int) -> HTMLResponse:
        with Database(config.paths.database) as db:
            query = db.get_saved_query(query_id)
            if query is None:
                raise HTTPException(404, "Saved query not found")
        return render(
            request,
            "query_edit.html",
            query=_query_view(query, config),
            is_new=False,
            model_profiles=config.available_llms,
        )

    @app.post("/queries")
    async def create_query(request: Request) -> RedirectResponse:
        form = await request.form()
        try:
            execution = _query_execution_form(form, config)
            with Database(config.paths.database) as db:
                query_id = db.create_saved_query(
                    name=str(form.get("name", "")),
                    prompt=str(form.get("prompt", "")),
                    auto_run_papers=str(form.get("auto_run_papers", ""))
                    in {"1", "true", "on"},
                    auto_run_blogs=str(form.get("auto_run_blogs", ""))
                    in {"1", "true", "on"},
                    **execution,
                )
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/queries/new", str(exc), level="error"), status_code=303
            )
        return RedirectResponse(
            _notice_url(f"/queries/{query_id}/edit", "Saved query created."),
            status_code=303,
        )

    @app.post("/queries/{query_id}/edit")
    async def edit_query(request: Request, query_id: int) -> RedirectResponse:
        form = await request.form()
        try:
            execution = _query_execution_form(form, config)
            legacy_target_form = not any(
                key in form
                for key in (
                    "model", "context_window_tokens", "paper_source_scope", "pdf_strategy",
                    "content_scope",
                )
            )
            with Database(config.paths.database) as db:
                changed = db.update_saved_query(
                    query_id,
                    name=str(form.get("name", "")),
                    prompt=str(form.get("prompt", "")),
                    auto_run_papers=(
                        str(form.get("auto_run_papers", "")) in {"1", "true", "on"}
                        if legacy_target_form else None
                    ),
                    auto_run_blogs=(
                        str(form.get("auto_run_blogs", "")) in {"1", "true", "on"}
                        if legacy_target_form else None
                    ),
                    **execution,
                )
            if not changed:
                raise HTTPException(404, "Saved query not found")
        except ValueError as exc:
            return RedirectResponse(
                _notice_url(f"/queries/{query_id}/edit", str(exc), level="error"),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url(f"/queries/{query_id}/edit", "Saved query updated."),
            status_code=303,
        )

    @app.post("/queries/automatic")
    async def update_automatic_queries(request: Request) -> Response:
        form = await request.form()
        query_ids = [
            value for raw in form.getlist("query_id")
            if (value := _int_or_none(raw)) is not None
        ]
        paper_ids = [
            value for raw in form.getlist("auto_run_papers")
            if (value := _int_or_none(raw)) is not None
        ]
        blog_ids = [
            value for raw in form.getlist("auto_run_blogs")
            if (value := _int_or_none(raw)) is not None
        ]
        with Database(config.paths.database) as db:
            db.update_automatic_queries(
                query_ids,
                paper_query_ids=paper_ids,
                blog_query_ids=blog_ids,
            )
        if request.headers.get("X-Paperwatch-Async") == "1":
            return JSONResponse(
                {"ok": True, "message": "Automatic query selections updated."}
            )
        return RedirectResponse(
            _notice_url("/queries", "Automatic query selections updated."),
            status_code=303,
        )

    @app.post("/queries/{query_id}/delete")
    def delete_query(query_id: int) -> RedirectResponse:
        with Database(config.paths.database) as db:
            query = db.get_saved_query(query_id)
            if query is None:
                raise HTTPException(404, "Saved query not found")
            if bool(query["is_builtin"]):
                return RedirectResponse(
                    _notice_url("/queries", "Summarize is a built-in prompt and cannot be deleted.", level="warning"),
                    status_code=303,
                )
            db.delete_saved_query(query_id)
        return RedirectResponse(_notice_url("/queries", "Saved query deleted."), status_code=303)

    @app.post("/queries/{query_id}/classifications/delete")
    def delete_query_classifications(query_id: int) -> RedirectResponse:
        with Database(config.paths.database) as db:
            query = db.get_saved_query(query_id)
            if query is None:
                raise HTTPException(404, "Saved query not found")
            removed = db.clear_query_classifications(query_id)
        return RedirectResponse(
            _notice_url(
                f"/queries#query-{query_id}",
                f"Removed {removed} classification result{'s' if removed != 1 else ''}.",
            ),
            status_code=303,
        )

    @app.post("/queries/{query_id}/run")
    async def run_query(request: Request, query_id: int) -> RedirectResponse:
        form = await request.form()
        profiles = tuple(str(value) for value in form.getlist("model"))
        context = _int_or_none(form.get("context_window_tokens")) or DEFAULT_CONTEXT_WINDOW_TOKENS
        source_scope = str(form.get("source_scope", "abstract"))
        pdf_strategy = str(form.get("pdf_strategy", "auto"))
        try:
            batch_id = collection_controller.start(
                query_id,
                profiles,
                context,
                source_scope=source_scope,
                pdf_strategy=pdf_strategy,
            )
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/queries", str(exc), level="error"), status_code=303
            )
        if batch_id is None:
            return RedirectResponse(
                _notice_url("/queries", "Another collection query is already running.", level="warning"),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url("/queries", f"Started query with {len(set(profiles))} model(s)."),
            status_code=303,
        )

    @app.post("/queries/run-filtered")
    async def run_filtered_query(request: Request) -> RedirectResponse:
        form = await request.form()
        query_id = _int_or_none(form.get("query_id"))
        profiles = tuple(str(value) for value in form.getlist("model") if str(value))
        context = _int_or_none(form.get("context_window_tokens")) or DEFAULT_CONTEXT_WINDOW_TOKENS
        source_scope = str(form.get("source_scope", "abstract"))
        pdf_strategy = str(form.get("pdf_strategy", "auto"))
        if query_id is None:
            return RedirectResponse(
                _notice_url("/", "Select a saved query.", level="error"), status_code=303
            )
        filters = _parse_filter_values(form)
        with Database(config.paths.database) as db:
            stored_query = db.get_saved_query(query_id)
            local_regexp = bool(
                stored_query
                and str(stored_query["regexp_pattern"] or "").strip()
                and str(stored_query["regexp_mode"] or "query") == "print"
            )
            authors_for_labels = db.list_authors_with_tags(tracked_only=True)
            topics_for_labels = db.list_topics()
        available_profiles = {item.profile for item in config.available_llms}
        if not local_regexp and (
            not profiles or any(name not in available_profiles for name in profiles)
        ):
            return RedirectResponse(
                _notice_url("/", "Select a configured model.", level="error"), status_code=303
            )
        selection = _selection_with_labels(
            filters, authors=authors_for_labels, topics=topics_for_labels
        )
        selected_ids: list[int] = []
        raw_ids = str(form.get("paper_ids", ""))
        for value in raw_ids.split(","):
            paper_id = _int_or_none(value.strip())
            if paper_id is not None and paper_id > 0:
                selected_ids.append(paper_id)
        if selected_ids:
            selected_ids = list(dict.fromkeys(selected_ids))[:5000]
            selection["paper_ids"] = selected_ids
            selection["labels"] = [f"Selected papers: {len(selected_ids)}"]
        try:
            batch_id = collection_controller.start(
                query_id,
                profiles,
                context,
                selection=selection,
                source_scope=source_scope,
                pdf_strategy=pdf_strategy,
            )
        except ValueError as exc:
            return RedirectResponse(_notice_url("/", str(exc), level="error"), status_code=303)
        if batch_id is None:
            return RedirectResponse(
                _notice_url("/", "Another collection query is already running.", level="warning"),
                status_code=303,
            )
        target = _notice_url(
            f"/queries?focus={query_id}",
            f"Started saved query with {len(set(profiles))} model(s).",
        )
        return RedirectResponse(f"{target}#query-{query_id}", status_code=303)

    @app.post("/queries/{query_id}/run-existing/{content_type}")
    async def run_query_on_existing(
        request: Request, query_id: int, content_type: str
    ) -> RedirectResponse:
        if content_type not in {"papers", "blogs"}:
            raise HTTPException(404, "Unknown content type")
        form = await request.form()
        with Database(config.paths.database) as db:
            stored = db.get_saved_query(query_id)
            if stored is None:
                raise HTTPException(404, "Saved query not found")
            query = _query_view(stored, config)
            selection: dict[str, Any] = {
                "content_type": content_type,
                "labels": [f"All existing {content_type}"],
            }
            if content_type == "papers":
                rows, _ = db.search_papers(limit=None, offset=0)
                eligible_ids = [
                    int(row["id"])
                    for row in rows
                    if str(row["abstract"] or "").strip()
                    or str(row["pdf_url"] or "").strip()
                    or str(row["local_pdf_path"] or "").strip()
                ]
                selection["paper_ids"] = eligible_ids
        requested_profiles = tuple(
            str(value) for value in form.getlist("model") if str(value).strip()
        )
        profiles = requested_profiles or tuple(query["model_profiles"])
        if not profiles and not query["local_regexp"]:
            return RedirectResponse(
                _notice_url(
                    f"/queries/{query_id}/edit",
                    "Select at least one configured model before running this query.",
                    level="error",
                ),
                status_code=303,
            )
        source_scope = (
            "blog" if content_type == "blogs" else str(query["paper_source_scope"])
        )
        pdf_strategy = (
            "auto" if content_type == "blogs" else str(query["pdf_strategy"])
        )
        try:
            batch_id = collection_controller.start(
                query_id,
                profiles,
                _int_or_none(form.get("context_window_tokens"))
                or int(query["context_window_tokens"]),
                selection=selection,
                source_scope=source_scope,
                pdf_strategy=pdf_strategy,
                content_type=content_type,
            )
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/queries", str(exc), level="error"), status_code=303
            )
        if batch_id is None:
            return RedirectResponse(
                _notice_url(
                    "/queries",
                    "Another saved prompt is already running.",
                    level="warning",
                ),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url(
                "/queries",
                f"Started {query['name']} on all existing {content_type} with "
                f"{len(profiles)} saved model(s).",
            ),
            status_code=303,
        )

    @app.post("/queries/run-blogs")
    async def run_blog_query(request: Request) -> RedirectResponse:
        form = await request.form()
        query_id = _int_or_none(form.get("query_id"))
        profiles = tuple(str(value) for value in form.getlist("model") if str(value))
        context = _int_or_none(form.get("context_window_tokens")) or DEFAULT_CONTEXT_WINDOW_TOKENS
        if query_id is None:
            return RedirectResponse(
                _notice_url("/blogs", "Select a saved query.", level="error"),
                status_code=303,
            )
        selected_ids: list[int] = []
        for raw in form.getlist("blog_entry_id"):
            entry_id = _int_or_none(raw)
            if entry_id is not None and entry_id > 0:
                selected_ids.append(entry_id)
        selection: dict[str, Any] = {
            "content_type": "blogs",
            "labels": [
                f"Visible blog entries: {len(set(selected_ids))}"
                if selected_ids
                else "All blog entries"
            ],
        }
        if selected_ids:
            selection["blog_entry_ids"] = list(dict.fromkeys(selected_ids))[:5000]
        try:
            batch_id = collection_controller.start(
                query_id,
                profiles,
                context,
                selection=selection,
                source_scope="blog",
                pdf_strategy="auto",
                content_type="blogs",
            )
        except ValueError as exc:
            return RedirectResponse(
                _notice_url("/blogs", str(exc), level="error"), status_code=303
            )
        if batch_id is None:
            return RedirectResponse(
                _notice_url(
                    "/blogs", "Another saved prompt is already running.", level="warning"
                ),
                status_code=303,
            )
        return RedirectResponse(
            _notice_url("/blogs", "Started saved query on blog entries."),
            status_code=303,
        )

    @app.get("/api/query-status")
    def query_status() -> JSONResponse:
        return JSONResponse(asdict(collection_controller.snapshot()))

    @app.post("/api/query-cancel")
    def cancel_query() -> JSONResponse:
        cancelled = collection_controller.cancel()
        return JSONResponse(
            {"ok": cancelled, "message": "Cancellation requested" if cancelled else "No saved prompt is running"},
            status_code=200 if cancelled else 409,
        )

    @app.get("/api/running-status")
    def running_status() -> JSONResponse:
        return JSONResponse(
            {
                "fetch": asdict(controller.snapshot()),
                "analysis": asdict(model_controller.snapshot()),
                "query": asdict(collection_controller.snapshot()),
            }
        )

    def _data_actions_available() -> bool:
        return not (
            controller.snapshot().running
            or model_controller.snapshot().running
            or collection_controller.snapshot().running
        )

    @app.post("/data/delete/authors")
    def delete_all_authors() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count = db.delete_all_authors()
        return RedirectResponse(
            _notice_url("/runs", f"Deleted {count} author record(s)."), status_code=303
        )

    @app.post("/data/delete/papers")
    def delete_all_papers() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count, paths = db.delete_all_papers()
        root = config.paths.pdf_dir.resolve()
        removed = 0
        for value in paths:
            path = Path(value).expanduser().resolve()
            if path.is_file() and (path == root or root in path.parents):
                path.unlink(missing_ok=True)
                removed += 1
        return RedirectResponse(
            _notice_url(
                "/runs", f"Deleted {count} paper record(s) and {removed} stored PDF(s)."
            ),
            status_code=303,
        )

    @app.post("/data/delete/blogs")
    def delete_all_downloaded_blogs() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count = db.delete_all_blog_entries()
        return RedirectResponse(
            _notice_url(
                "/runs",
                f"Deleted {count} downloaded blog entr{'y' if count == 1 else 'ies'}; source links were kept.",
            ),
            status_code=303,
        )

    @app.post("/data/delete/summaries")
    def delete_all_summaries() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count = db.delete_all_summaries()
        return RedirectResponse(
            _notice_url(
                "/runs",
                f"Deleted {count} generated summar{'y' if count == 1 else 'ies'} and their task history.",
            ),
            status_code=303,
        )

    @app.post("/data/delete/fetch-history")
    def delete_fetch_history() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count = db.delete_fetch_history()
        return RedirectResponse(
            _notice_url(
                "/runs",
                f"Deleted {count} fetch-history record{'s' if count != 1 else ''}.",
            ),
            status_code=303,
        )

    @app.post("/data/delete/queries")
    def delete_all_queries() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count = db.delete_all_queries()
        return RedirectResponse(
            _notice_url(
                "/runs",
                f"Deleted {count} saved quer{'y' if count == 1 else 'ies'}; the built-in query was restored.",
            ),
            status_code=303,
        )

    @app.post("/data/delete/query-history")
    def delete_query_history() -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before deleting data.", level="warning"),
                status_code=303,
            )
        with Database(config.paths.database) as db:
            count = db.delete_query_history()
        return RedirectResponse(
            _notice_url(
                "/runs",
                f"Deleted {count} saved-query output record{'s' if count != 1 else ''}.",
            ),
            status_code=303,
        )

    @app.get("/data/export/authors-blogs")
    def export_authors_blogs() -> JSONResponse:
        with Database(config.paths.database) as db:
            payload = db.export_author_blog_catalog()
        return JSONResponse(
            payload,
            headers={
                "Content-Disposition": 'attachment; filename="paperwatch-authors-blogs.json"'
            },
        )

    @app.post("/data/import/authors-blogs")
    async def import_authors_blogs(request: Request) -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before importing data.", level="warning"),
                status_code=303,
            )
        form = await request.form()
        upload = form.get("file")
        if not isinstance(upload, UploadFile):
            return RedirectResponse(
                _notice_url("/runs", "Choose an authors and blogs JSON file.", level="error"),
                status_code=303,
            )
        try:
            raw = await upload.read(20_000_001)
            if len(raw) > 20_000_000:
                raise ValueError("Authors and blogs import exceeds 20 MB")
            payload = json.loads(raw.decode("utf-8-sig"))
            if not isinstance(payload, dict):
                raise ValueError("Authors and blogs import must be a JSON object")
            with Database(config.paths.database) as db:
                authors_count, links_count = db.import_author_blog_catalog(payload)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            return RedirectResponse(
                _notice_url("/runs", str(exc), level="error"), status_code=303
            )
        finally:
            await upload.close()
        return RedirectResponse(
            _notice_url(
                "/runs",
                f"Imported {authors_count} author(s) and {links_count} author-blog link(s).",
            ),
            status_code=303,
        )

    @app.get("/data/export/all")
    def export_all_data() -> FileResponse:
        handle, archive_name = tempfile.mkstemp(prefix="paperwatch-export-", suffix=".zip")
        os.close(handle)
        archive = Path(archive_name)
        with tempfile.TemporaryDirectory(prefix="paperwatch-export-db-") as temporary:
            database_copy = Path(temporary) / "database.sqlite3"
            with Database(config.paths.database) as db:
                db.backup_to(database_copy)
            pdf_root = config.paths.pdf_dir.resolve()
            pdf_paths: dict[str, str] = {}
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
                bundle.write(database_copy, "database.sqlite3")
                if pdf_root.is_dir():
                    for file in sorted(pdf_root.rglob("*")):
                        if not file.is_file() or file.is_symlink():
                            continue
                        relative = file.relative_to(pdf_root).as_posix()
                        bundle.write(file, f"pdfs/{relative}")
                        pdf_paths[str(file.resolve())] = relative
                bundle.writestr(
                    "manifest.json",
                    json.dumps(
                        {
                            "format": "paperwatch-full-data",
                            "version": 1,
                            "created_at": _utcnow(),
                            "pdf_paths": pdf_paths,
                        },
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
        return FileResponse(
            archive,
            media_type="application/zip",
            filename="paperwatch-full-data.zip",
            background=BackgroundTask(archive.unlink, missing_ok=True),
        )

    @app.post("/data/import/all")
    async def import_all_data(request: Request) -> RedirectResponse:
        if not _data_actions_available():
            return RedirectResponse(
                _notice_url("/runs", "Stop active jobs before importing data.", level="warning"),
                status_code=303,
            )
        form = await request.form()
        upload = form.get("file")
        if not isinstance(upload, UploadFile):
            return RedirectResponse(
                _notice_url("/runs", "Choose a Paperwatch full-data ZIP file.", level="error"),
                status_code=303,
            )
        staging_root = Path(tempfile.mkdtemp(prefix="paperwatch-import-"))
        uploaded = staging_root / "upload.zip"
        try:
            total = 0
            with uploaded.open("wb") as handle:
                while chunk := await upload.read(1024 * 1024):
                    total += len(chunk)
                    if total > 5_000_000_000:
                        raise ValueError("Full-data import exceeds 5 GB")
                    handle.write(chunk)
            if not zipfile.is_zipfile(uploaded):
                raise ValueError("Full-data import is not a ZIP archive")
            database_copy = staging_root / "database.sqlite3"
            pdf_stage = staging_root / "pdfs"
            pdf_stage.mkdir()
            with zipfile.ZipFile(uploaded) as bundle:
                names = set(bundle.namelist())
                if "database.sqlite3" not in names or "manifest.json" not in names:
                    raise ValueError("Full-data archive is missing its database or manifest")
                manifest = json.loads(bundle.read("manifest.json").decode("utf-8"))
                if not isinstance(manifest, dict) or manifest.get("format") != "paperwatch-full-data":
                    raise ValueError("Unsupported full-data archive")
                database_copy.write_bytes(bundle.read("database.sqlite3"))
                for name in names:
                    if not name.startswith("pdfs/") or name.endswith("/"):
                        continue
                    relative = Path(name.removeprefix("pdfs/"))
                    if relative.is_absolute() or ".." in relative.parts:
                        raise ValueError("Full-data archive contains an unsafe path")
                    destination = pdf_stage / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with bundle.open(name) as source, destination.open("wb") as target:
                        shutil.copyfileobj(source, target)
            check = sqlite3.connect(str(database_copy))
            try:
                result = check.execute("PRAGMA quick_check").fetchone()
                tables = {
                    str(row[0])
                    for row in check.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    ).fetchall()
                }
            finally:
                check.close()
            if not result or result[0] != "ok" or not {"authors", "papers", "blogs", "blog_entries"} <= tables:
                raise ValueError("Full-data database is invalid")
            with Database(database_copy):
                pass
            pdf_mapping = manifest.get("pdf_paths") if isinstance(manifest.get("pdf_paths"), dict) else {}
            if pdf_mapping:
                conn = sqlite3.connect(str(database_copy))
                try:
                    for old_path, relative in pdf_mapping.items():
                        relative_path = Path(str(relative))
                        if relative_path.is_absolute() or ".." in relative_path.parts:
                            continue
                        destination = config.paths.pdf_dir.resolve() / relative_path
                        conn.execute(
                            "UPDATE papers SET local_pdf_path=? WHERE local_pdf_path=?",
                            (str(destination), str(old_path)),
                        )
                    conn.commit()
                finally:
                    conn.close()
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            database_target = config.paths.database.resolve()
            database_target.parent.mkdir(parents=True, exist_ok=True)
            if database_target.exists():
                backup = database_target.with_name(f"{database_target.name}.before-import-{stamp}")
                shutil.copy2(database_target, backup)
            for suffix in ("-wal", "-shm"):
                Path(str(database_target) + suffix).unlink(missing_ok=True)
            os.replace(database_copy, database_target)
            pdf_target = config.paths.pdf_dir.resolve()
            if pdf_target.exists():
                pdf_backup = pdf_target.with_name(f"{pdf_target.name}.before-import-{stamp}")
                if pdf_backup.exists():
                    shutil.rmtree(pdf_backup)
                os.replace(pdf_target, pdf_backup)
            os.replace(pdf_stage, pdf_target)
        except (OSError, sqlite3.Error, zipfile.BadZipFile, json.JSONDecodeError, ValueError) as exc:
            return RedirectResponse(
                _notice_url("/runs", f"Import failed: {exc}", level="error"), status_code=303
            )
        finally:
            await upload.close()
            shutil.rmtree(staging_root, ignore_errors=True)
        return RedirectResponse(
            _notice_url("/runs", "Imported the full Paperwatch database and PDF store."),
            status_code=303,
        )

    @app.get("/runs", response_class=HTMLResponse)
    def runs(request: Request) -> HTMLResponse:
        active_jobs: list[dict[str, Any]] = []
        fetch_snapshot = controller.snapshot()
        analysis_snapshot = model_controller.snapshot()
        query_snapshot = collection_controller.snapshot()
        if fetch_snapshot.running:
            active_jobs.append(
                {
                    "kind": "Fetch",
                    "live_kind": "fetch",
                    "status": "running",
                    "name": fetch_snapshot.stage or "Fetch now",
                    "model": "—",
                    "papers": [],
                    "blogs": [],
                    "started_at": fetch_snapshot.started_at,
                    "progress_current": fetch_snapshot.progress_current,
                    "progress_total": fetch_snapshot.progress_total,
                    "message": fetch_snapshot.message,
                }
            )
        with Database(config.paths.database) as db:
            rows = db.list_runs(100)
            for task in db.active_analysis_tasks():
                live = (
                    analysis_snapshot.running
                    and str(task["batch_id"]) == str(analysis_snapshot.batch_id)
                )
                active_jobs.append(
                    {
                        "kind": "Summary",
                        "live_kind": "analysis" if live else "",
                        "status": task["status"],
                        "name": f"{task['scope']} analysis",
                        "model": task["model"],
                        "paper_id": int(task["paper_id"]),
                        "paper_title": task["paper_title"],
                        "papers": [{"id": int(task["paper_id"]), "title": task["paper_title"]}],
                        "started_at": task["started_at"] or task["created_at"],
                        "progress_current": analysis_snapshot.progress_current if live else 0,
                        "progress_total": analysis_snapshot.progress_total if live else 0,
                        "message": analysis_snapshot.message if live else "",
                    }
                )
            for query_run in db.active_query_runs():
                live = (
                    query_snapshot.running
                    and str(query_run["batch_id"]) == str(query_snapshot.batch_id)
                )
                paper_id: int | None = None
                paper_title: str | None = None
                papers_for_job: list[dict[str, Any]] = []
                blogs_for_job: list[dict[str, Any]] = []
                selection = _json_value(query_run["selection_json"], {})
                values = selection.get("paper_ids") if isinstance(selection, dict) else None
                if isinstance(values, list):
                    for value in values[:20]:
                        selected_id = _int_or_none(value)
                        paper = db.get_paper(selected_id) if selected_id is not None else None
                        if paper is not None:
                            papers_for_job.append({"id": selected_id, "title": str(paper["title"])})
                    if len(papers_for_job) == 1:
                        paper_id = int(papers_for_job[0]["id"])
                        paper_title = str(papers_for_job[0]["title"])
                blog_values = (
                    selection.get("blog_entry_ids")
                    if isinstance(selection, dict)
                    else None
                )
                if isinstance(blog_values, list):
                    selected_blog_ids = [
                        value
                        for value in (_int_or_none(item) for item in blog_values[:20])
                        if value is not None
                    ]
                    for entry in db.blog_entries_by_ids(selected_blog_ids):
                        blogs_for_job.append(
                            {"id": int(entry["id"]), "title": str(entry["title"])}
                        )
                active_jobs.append(
                    {
                        "kind": "Saved prompt",
                        "live_kind": "query" if live else "",
                        "status": query_run["status"],
                        "name": query_run["query_name"],
                        "model": query_run["model"],
                        "paper_id": paper_id,
                        "paper_title": paper_title,
                        "papers": papers_for_job,
                        "blogs": blogs_for_job,
                        "started_at": query_run["started_at"] or query_run["created_at"],
                        "progress_current": query_snapshot.progress_current if live else 0,
                        "progress_total": query_snapshot.progress_total if live else 0,
                        "message": query_snapshot.message if live else "",
                    }
                )
        return render(request, "runs.html", runs=rows, active_jobs=active_jobs)

    @app.get("/runs/{run_id}", response_class=HTMLResponse)
    def run_detail(request: Request, run_id: int) -> HTMLResponse:
        with Database(config.paths.database) as db:
            run = db.get_run(run_id)
            if run is None:
                raise HTTPException(404, "Run not found")
            errors = db.get_run_errors(run_id)
        return render(request, "run_detail.html", run=run, errors=errors)

    return app
