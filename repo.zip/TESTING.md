# Automated testing strategy — paperwatch 0.9.9

The default suite is deterministic and requires no live OpenAlex index, arXiv service, Ollama server, OpenAI account, PDF host, or external browser assets.

```bash
pytest
```

`pyproject.toml` enables branch coverage and fails below 95%.

Release result:

- 374 tests passed
- Existing 95% branch-coverage gate retained
- Shared notes, author/blog-source tags, bulk tag undo, CSV metadata round trips,
  PDF replacement/integrity state, asynchronous filters and regexp test panes
- Python 3.13.5 release environment

## Feature coverage

| Area | Automated checks |
|---|---|
| Configuration | TOML parsing, generated defaults, relative paths, environment keys, ranges, metadata-only mode, Ollama/OpenAI/Codex/Claude Code profiles, profile names, commands, reasoning effort, context windows |
| Author lifecycle | Add/update/re-enable, pause, non-destructive archive, archived-row retention, restoration, coauthor relinking |
| Author tags | Multiple tags, normalization, suggestions, duplicate handling, removal, filtering, archived-author visibility rules |
| Paper author controls | First-tracked/default-first selection, orange tracked-author markers, picker state, local searches, OpenAlex/Scholar/arXiv links, missing IDs, failed lookup notices |
| OpenAlex | Authentication, author search/get, exact work lookup/download, title search, work filtering/sorting, cursor pagination, retries, malformed responses, sparse title-less work skipping, metadata normalization |
| Deduplication | DOI, arXiv, OpenAlex, title/year, and same-run coauthor cases |
| arXiv enrichment | ID/title lookup, author verification, polite throttling, retries, malformed XML, missing fields, conditional calls |
| PDFs | Safe paths, redirect handling, limits, PDF signatures, readable-upload validation, atomic writes, cache reuse, extraction failures |
| LLM providers | Ollama/OpenAI/Codex strict-schema requests, Claude Code headless JSON-schema execution, local command readiness/timeouts/termination, Ollama `num_ctx`, model readiness, actionable missing-model errors, native/OpenAI-compatible local endpoints, context override, output variants, usage, malformed output, HTTP failures |
| Structured summaries | Exact keys/enums, narrative limits, `Setting: ` requirement, trusted metadata normalization, named-column and JSON round trips |
| Chunked analysis | Paragraph splitting, overlap, chunk-size budgets, direct-fit checks, chunk-note cache, recursive reduction, final strict schema, context failures |
| Multi-model analysis | Direct/auto/chunked modes, same-source runs, partial failures, cache reuse, context overrides, source validation |
| Saved queries | Protected built-in Summarize prompt, paper/blog/both support scope, optional no-op regexp preprocessing, bounded match radius, local print mode, direct result pages, runtime abstract/full-PDF/blog source, exact mixed-content selection, map/reduce grouping, oversized record splitting/compaction, multi-model success/failure, status recovery |
| Pipeline | Cursor-independent one-year download-only backfill, historical-analysis suppression, late-PDF analysis, normal initial/overlap windows, model preflight, automatic PDF chunking, cache behavior, error isolation, counters |
| Concurrency | Separate cross-process fetch, paper-analysis, and saved-query locks; clean release behavior |
| SQLite | Transactions, WAL, foreign keys, schema guards, migrations through schema v9, historical paper flags, tag/query/chunk persistence, integrity |
| Unified download UI | Color-coded paper/blog rows, author-page links, explicit all/papers/blogs content-type filtering, shared text/author/date/tag filters, blog-tag column, remote image rendering without persistent media downloads, searchable selects with keyboard insertion and clear-on-reselect, persistent row selection, direct page-number jumps, exports, 25–1000 pagination, system/light/dark theme control, visible running version |
| Paper UI | Consolidated identifier/external/action metadata panel, author picker state, model reruns, saved prompts, 16384-token default context input, no-reload fragment refresh, scroll preservation, live output, cancellation, stale-attempt recovery, analysis rendering, exports |
| Discovery/author/query UI | Mutually exclusive Paper/Author OpenAlex discovery modes, review-before-download, manual PDF import/backfill, table-based author filtering, Enter-to-tag, icon pause/resume/archive controls, protected Summarize prompt, prompt-only query CRUD, runtime source/strategy/context/model controls, persisted selections/outputs/errors |
| Static resilience | System/light/dark preference cycle, hidden-state CSS precedence, no CDN dependency, responsive templates |
| Web security | CSP with explicit remote image allowance, sanitized stored HTML/markdown, rejection of non-HTTP media links, frame denial, MIME-sniff prevention, same-origin referrer policy, protected local-PDF paths, safe `xdg-open` invocation without a shell, guarded destructive/import actions, localhost default |
| Data management | Delete authors/papers/blog entries/generated summaries/query definitions/query history/fetch history, constrained PDF cleanup, author/blog JSON round trip, full SQLite/PDF ZIP round trip, archive validation, unsafe-path rejection, active-job blocking |
| CLI/systemd | CLI commands, web invocation, daily timer, web service files, archive wording |
| Packaging | Prompt/config/templates/assets/new modules included in wheel; installed command/server smoke tests |

## Test layers

1. **Unit tests** isolate parsing, validation, chunk budgets, schema conversion, URL generation, and database methods.
2. **Service tests** use deterministic HTTP transports and fake LLMs to exercise retries, malformed responses, and partial failures.
3. **Pipeline tests** execute full author-to-paper-to-analysis flows against temporary SQLite databases.
4. **Web integration tests** use FastAPI's test client to submit forms, follow redirects, inspect rendered HTML, poll status APIs, and download exports.
5. **Release smoke tests** install the built wheel, start the actual Uvicorn application, and send real local HTTP requests.
6. **Visual checks** render seeded recent-paper, detail, authors, queries, dark-theme, and mobile pages to inspect hierarchy and responsive behavior.

## Release procedure

```bash
python -m compileall -q src tests
pytest -q --no-cov
pytest -q
python -m build --wheel
# Offline fallback when build isolation cannot download its requirements:
python -m pip wheel . --no-deps --no-build-isolation -w dist
```

The release audit then verifies:

1. wheel contents include templates, static assets, defaults, prompt, and all runtime modules;
2. installation into an isolated environment;
3. generated `config.toml` parses without duplicate keys;
4. installed CLI and Web server start successfully;
5. local HTTP responses for `/`, paper detail, authors, queries, status APIs, exports, CSS, and JavaScript;
6. model selectors, context controls, author actions, tags, and saved-query controls render from the wheel;
7. an installed-package chunk/map/reduce run persists expected rows and reuses its chunk/final caches;
8. a repeated identical run uses caches where applicable;
9. `PRAGMA integrity_check` returns `ok`;
10. `systemd-analyze verify` accepts all supplied units;
11. release SHA-256 checksums match.

## Deliberately excluded live tests

The deterministic suite does not call production OpenAlex, arXiv, Ollama, or OpenAI endpoints or the Claude Code executable. This avoids nondeterminism, credentials, costs, and upstream rate limits. Their current request/response contracts and error paths are represented by controlled fixtures and mock servers. A deployment should still perform one manual credentialed smoke run with its chosen model and network environment.

## Codex coverage

The offline suite verifies:

- Codex provider configuration and `OPENAI_API_KEY` fallback;
- Responses API endpoint, authorization, strict schema, and reasoning payload;
- original PDF multipart upload, `input_file` attachment, and remote-file deletion;
- direct/auto Codex PDF routing without local text extraction, including the daily pipeline;
- provider-specific missing-key, rejected-key, inaccessible-model, and server errors;
- factory creation and Web UI profile rendering;
- distinct direct and chunked cache entries when reasoning effort changes;
- validation of supported effort values and rejection on unsupported providers.


## Claude Code coverage

The offline suite verifies:

- configuration without an API key and custom executable paths;
- schema-constrained `claude -p` arguments, model and effort propagation, stdin prompt delivery, and usage metadata;
- factory creation and model attribution;
- missing executable, process-start failure, nonzero exit, malformed envelopes, missing structured output, and schema validation errors;
- timeout termination followed by forced kill when graceful shutdown does not complete.
